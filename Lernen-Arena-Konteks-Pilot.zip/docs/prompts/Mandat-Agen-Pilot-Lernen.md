# Mandat agen · Lernen, visual novel untuk belajar bahasa Jerman

**Kedudukan tugas per PRD v1.7.** Ini paket uji pertama untuk agen pelaksana. Setelah serah terima pilot, Asisten Director wajib menugaskan kelanjutan sesuai [mandat induk](../Mandat-Induk-Ketuntasan-A1-B2.md), termasuk 42 unit sampai B2, uji ketuntasan per keterampilan, perbaikan dan evaluasi hasil peserta.

Kamu adalah pemilik implementasi dan pengujian satu kandidat Lernen. Perbaiki aplikasi yang ada sampai seorang pelajar pemula bisa memilih tokoh, berkenalan dengan tetangga, lalu mencoba misi stasiun yang melatih empat keterampilan bahasa Jerman. Serahkan kandidat yang bisa saya buka sendiri, bukti dari kandidat itu, dan petunjuk untuk meneruskan pekerjaan. Mulailah dari kode, naskah, gambar dan suara yang tersedia. Jika bekerja sendiri, jalankan seluruh peran di bawah secara berurutan. Jika bekerja dalam tim, gunakan satu kandidat integrasi dan satu penanggung jawab untuk setiap file bersama.

## 1. Hasil uji coba dan batas pengerjaan

**Yang harus saya bisa lakukan ketika membuka hasilmu:**

1. Dari layar judul, pilih satu dari empat avatar produksi, dengarkan contoh suaranya, beri nama, lalu temui Frau Lehmann dan Mia.
2. Jawab Mia. Lihat perbedaan respons ketika hanya menyapa, menyebut nama, menggunakan kalimat lengkap, atau meminta bantuan. Keluar lalu lanjut dari posisi yang sama.
3. Masuk ke *Latih keterampilan → Peron berubah*. Izinkan penguji langsung memilih misi ini dari jalur pengguna biasa. Memilih latihan tidak menandai Bab 01–10 selesai.
4. Baca tiket, dengarkan perubahan peron, tanyakan jalur secara lisan kepada petugas, lalu tulis pesan kepada Mia. Lihat apa yang benar-benar dilatih pada tiap giliran.
5. Buka jurnal. Hasil cerita, latihan dengan bantuan, keberhasilan mandiri dan hasil simulasi harus bisa dibedakan. Pustaka, materi A1–B2 dan progres lama tetap terjangkau.

**Target pilot:** prolog sampai perkenalan dengan Mia dan satu rangkaian utuh Bab 11–12. Pertahankan pekerjaan tambahan yang sudah ada. **Kelanjutan setelah pilot:** seluruh A1, lalu satu misi A2, B1 dan B2 sebelum memperluas semua unit. Cantumkan kelanjutan itu dalam serah terima. Ukur keberhasilan pilot dari alur di atas. Jangan menandai seluruh kampanye siap berdasarkan satu contoh.

## 2. Temukan sumber yang benar sebelum mengedit

Repo publik: [alpanhk/APPlerner](https://github.com/alpanhk/APPlerner). Jika kamu mendapat checkout yang sudah berisi pekerjaan baru, baca status Git, cabang, commit, dan perubahan lokal. Telusuri komponen yang benar-benar dirender dari `src/main.tsx`. Ada dua jalur pengembangan yang pernah dipakai: versi GitHub di `src/klab/novel/` dan contoh lokal di `src/arena/` dengan `DesktopEntry.tsx`. Cocokkan keduanya, pilih satu titik integrasi aktif, dan gunakan implementasi yang sudah bekerja. Hindari menyalin seluruh cabang atau mereset pekerjaan orang lain. Untuk uji perbandingan agen, gunakan cabang/worktree terpisah dari commit awal yang dicatat.

| Acuan | Lokasi pada komputer proyek |
|---|---|
| Aturan produk dan pembelajaran | `E:/Belajar/APP belajar bahasa German/lernen-app/PRD-Aplikasi-Belajar-Bahasa-Jerman.md` v1.6 dan `docs/Visual-Novel-dan-Persiapan-Ujian.md` |
| Naskah, kurikulum, latihan | Pada proyek yang sama: `docs/naskah-visual-novel-a1/`, terutama Bab 01, 11, 12; `src/data/lessons/` dan `src/data/practice/` |
| UI/UX Arena yang dipilih pengguna | `C:/Users/REIN/Downloads/german-learning-visual-novel`. Bandingkan layar judul, pemilihan karakter, panggung, dialog, jurnal dan riwayat |
| Contoh integrasi sebelumnya | `E:/Belajar/APP belajar bahasa German/APPlerner-codex-agents/ui`, commit contoh `5d513376efd8`. Baca serah terima `lernen-app/outputs/koordinasi-ui-ux-a1/contoh-untuk-opencode.md` |
| Aset prolog | `E:/Belajar/APP belajar bahasa German/lernen-design/outputs/pemeran-visual-novel-a1/`: `players-a/manifest.json`, `players-b/manifest.json`, `npcs/manifest.json`, `voices/audio-index.json` |
| Aset bab | Di bawah `lernen-design/outputs/aset-chapter-a1/`: `latar/INDEX.json`, `karakter/manifest.json`, `properti/batch-01.json` sampai `batch-03.json`, `audio/speech-catalog.json` dan paket efek di `audio/sound-design/` |

**Jika bekerja di komputer lain:** cari nama file dan manifest relatif terhadap repo serta lampiran yang diberikan. Cek juga aset yang sudah dikemas dalam kandidat. Bila paket produksi belum tersedia, sebut paket, ID dan adegan yang membutuhkannya. Mintakan hanya berkas yang hilang dan lanjutkan bagian yang dapat diuji. Simpan lokasi sumber asli sebagai informasi asal; aplikasi yang diserahkan harus memuat media dari paketnya sendiri. Jangan memasukkan foto pengganti, gambar generik, suara acak, atau tautan ke drive pembuat sebagai hasil akhir.

## 3. Urutan dan pembagian peran

| Pemilik | Pekerjaan dan hasil yang diserahkan | Ketergantungan |
|---|---|---|
| Koordinator/integrator | Tetapkan commit dasar, target desktop atau browser, rute pengguna, ID adegan, dan revisi bersama. Integrasikan hasil, jalankan build, selesaikan konflik dan catat identitas kandidat. | Mulai dahulu. Publikasikan contoh satu giliran beserta data dan media bagi peran lain. |
| UI/UX | Kerjakan layar judul, pemilihan avatar, percakapan, interaksi benda, umpan balik dan jurnal. Pastikan fokus, ukuran kecil dan kendali audio dapat dipakai. | Bisa mulai dari frame dan cuplikan asli sambil menunggu mesin penilaian. |
| Konten/pedagogi | Cocokkan dialog, maksud jawaban, bentuk alternatif, bantuan, tugas baru dan rubrik. Tetapkan informasi mana yang harus disembunyikan ketika menguji menyimak. | Serahkan satu skenario acuan lebih dahulu agar UI, audio dan penguji memakai fakta yang sama. |
| Media/suara | Peta karakter–frame–suara, kemas aset runtime, periksa transkrip dan hak penggunaan, siapkan sinkronisasi mulut dan efek. | Ikuti ID yang digunakan naskah; beri tanda pada baris dengan nama atau angka dinamis. |
| Mesin aplikasi/data | Alur permainan, respons NPC, penyimpanan dan pemulihan, pemisahan bukti keterampilan, rekam/putar/hapus suara, bundel offline. | Integrasikan pada jalur utama. Gunakan layanan data lama saat masih sesuai. |
| QA | Siapkan profil baru dan salinan profil lama. Reproduksi kasus pada tabel penerimaan, periksa media nyata, beri temuan beserta versi dan uji kembali setelah perbaikan. | Mulai menyusun kasus sejak awal; nilai hasil produk pada kandidat yang bisa dijalankan. |

Jika satu agen mengerjakan semua peran, urutannya adalah audit → satu giliran lengkap → prolog → misi stasiun dan pesan → simpan/pulihkan → uji regresi → serah terima. Setelah tiap tahap, tulis hasil yang sudah dapat dicoba dan kerjakan tahap tersedia berikutnya. Jika satu klip belum ada, lanjutkan ke bagian lain dan simpan ID kekurangannya.

## 4. Arahan UI/UX dan penyutradaraan

**Layar judul.** Gunakan gaya gambar dan komposisi Arena yang dipilih. Profil baru melihat *Mulai cerita*. Profil dengan progres melihat *Lanjutkan* disertai lokasi terakhir, misalnya “Di depan rumah Mia”. Pustaka, pengaturan dan akses latihan tersedia sebagai tindakan sekunder. Pastikan pengguna sampai ke pengalaman ini dari peluncuran normal.

**Pilih karakter.** Tampilkan empat potret produksi: jaket indigo, kardigan terakota, mantel zaitun dan kemeja oker. Tampilkan satu potret pilihan lebih besar dengan satu kolom nama dan satu tombol *Mulai cerita*. Tombol *Dengar suara* memutar “Hallo!” dari ID avatar yang sedang dipilih. Memilih avatar lain menghentikan contoh sebelumnya. Tandai pilihan dengan bentuk/centang selain warna. Pada ukuran sempit, tata ulang kartu menjadi dua kolom. Pakai nama tampilan ramah pengguna. Simpan ID internal `player-01`–`player-04` secara terpisah dari nama bebas.

**Panggung percakapan.** Susun lapisan sebagai latar → potret → properti di posisi yang sesuai → panel dialog. Panel menampilkan nama penutur, satu ujaran Jerman, tombol *Dengar lagi*, *Arti*, dan tindakan berikutnya. Bedakan giliran tutor, NPC dan pemain lewat label, ekspresi dan fokus. Saat pemain menjawab, pertanyaan NPC tetap terlihat atau dapat dibuka kembali tanpa kehilangan draf. Animasi mulut hanya pada tokoh yang suaranya sedang berbunyi. Tubuh, kamera, serta tokoh pendengar tetap tenang. Ekspresi senyum atau bertanya berganti di batas giliran. Muat media berikut sebelum pergantian lokasi bila memungkinkan untuk menghindari panggung kosong.

**Interaksi dan akses.** Beri umpan balik saat tombol ditekan. Transisi pintu atau lokasi cukup pendek dan dapat dilewati; pergantian satu baris oleh penutur yang sama tidak perlu menggelapkan panggung. Klik cepat atau Enter dua kali hanya mengeksekusi satu tindakan. Setelah panel jurnal/riwayat dibuka, jeda audio; Escape menutup panel dan mengembalikan fokus. Saat bernavigasi dengan Tab, fokus terlihat dan tertahan di dalam dialog modal. Teks tetap terbaca pada 900×600 dan 1280×800, dengan terjemahan terbuka dan nama panjang. Sediakan takarir untuk ketukan dan pengumuman, pilihan minim gerak dan mode senyap.

**Jurnal.** Tampilkan hasil yang menjelaskan tindakan pemain, misalnya “Kamu menemukan jam tiba dari tiket. Untuk peron, kamu membuka transkrip.” Tawarkan satu tindakan *Coba jadwal lain*. Jika suatu bukti belum ada, jelaskan apa yang dapat dilakukan untuk mendapatkannya. Hindari persentase penguasaan atau label kesiapan ujian berdasarkan jumlah bab yang sudah dibuka.

## 5. Arahan ilustrasi, suara dan integrasi aset

1. **Pemetaan.** Untuk setiap giliran catat ID bab, adegan, tujuan, penutur, klip, frame, latar dan keadaan properti. Resolusi ID bekerja untuk build produksi dan mode offline. Ambil jalur berkas dari manifest dan pastikan berkas dapat didekode.
2. **Konsistensi wajah.** Gunakan frame produksi neutral, sedikit terbuka, terbuka, senyum, bertanya. Paket berbeda memakai `speak-small/open` atau `talk-small/open`, dengan posisi titik jangkar yang berbeda. Petakan ke fungsi yang sama. Pertahankan wajah, ukuran, arah cahaya dan posisi dasar di antara frame. Uji setiap avatar di panggung, bukan hanya di layar pilih.
3. **Suara pemain dan NPC.** Kunci `voiceId` ke pemeran. Contoh pilihan avatar tersedia pada `voices/runtime/player-01/respons-hallo.mp3` dan pola serupa untuk ketiga avatar lain. Klip demo dengan nama *Alex* hanya untuk demo bernama demikian. Nama bebas dan jawaban ketik tidak boleh terdengar sebagai nama atau kalimat yang berbeda. Sediakan teks atau klip netral yang cocok persis dengan dialog.
4. **Perilaku pemutar.** Mulai frame dari kejadian audio benar-benar bermain; berhenti pada selesai, error, jeda, bisu, keluar, atau saat giliran diganti. Hanya satu suara dialog aktif. Redupkan atau jedakan suasana ketika ada ujaran. Efek ketukan, pintu, kertas dan cangkir berbunyi sekali pada peristiwa yang tepat. Klik *Dengar lagi* memutar ulang ujaran tanpa menggandakan efek properti. Jangan putar audio sebelum interaksi pengguna jika browser melarangnya.
5. **Peron dan angka.** Cari transkrip “Achtung, der Zug fährt heute von Gleis vier ab.” di katalog Bab 11. Cocokkan klip, lokasi, angka 4, prompt, opsi, dan hasil dari satu skenario. Untuk variasi peron 5, periksa klip asli yang berbeda. Bila belum tersedia, jadikan variasi teks sebagai latihan membaca dan tandai kebutuhan audio. Pisahkan baris dialog petugas dari pengumuman pengeras suara sehingga mulut tokoh tidak bergerak saat pengeras suara berbunyi.
6. **Bukti media.** Catat ID, jalur runtime, penutur, bahasa, transkrip, panjang audio, sumber, serta status izin. Lakukan tes decode dan putar dari kandidat. Jika hanya dapat membuktikan pemutar berjalan, laporkan itu; mutu artikulasi dan kewajaran suara menunggu uji dengar. Kemas aset yang benar-benar digunakan. Gunakan media berizin untuk setiap target distribusi.

## 6. Naskah perilaku dan penilaian

### A. Prolog dan percakapan dengan Mia

- Pemain terbangun di kamar. Tampilkan catatan “Guten Morgen!” dan dua ketukan sebagai satu peristiwa naratif. Frau Lehmann mengaitkan pelajaran dengan keperluan langsung: menyambut tetangga di pintu.
- Berikan satu contoh salam dan satu bentuk memperkenalkan diri. Setelah itu tawarkan giliran. *Dengar lagi* dan *Arti* dapat dipilih. Beri petunjuk bertahap dari petunjuk makna → awal frasa “Ich …” → contoh lengkap.
- Mia membuka dengan “Hallo! Ich bin Mia. Und du?” Pertahankan pertanyaan selama giliran pemain. Jika pemain menjawab “Hallo!”, Mia dapat mengatakan “Hallo! Und wie heißt du?”. Jika ia memberi nama saja, lanjutkan cerita dan catat bahwa nama dipahami. Jika ia menjawab “Ich heiße Rina” atau “Ich bin Rina” dengan nama profil yang sesuai, terima keduanya. Gunakan kalimat alami dari naskah dan klip yang memang tersedia.
- Simpan dukungan yang dipakai pada percobaan tersebut. Meniru tutor, menjawab dengan nama saja dan menggunakan kalimat lengkap dalam situasi baru harus menghasilkan bukti berbeda. Nilai percobaan baru tanpa petunjuk secara mandiri hanya jika tugas dan bentuk jawaban memenuhi tujuan. Jawaban bebas yang belum dikenali harus bisa diklarifikasi tanpa mengulang bab.

### B. Misi stasiun A1 dan pesan kepada Mia

| Giliran | Implementasi | Bukti hasil |
|---|---|---|
| Baca tiket | Tampilkan tiket perjalanan yang memiliki jam berangkat dan tiba. Minta pemain menemukan salah satunya. Kesalahan menghasilkan koreksi spesifik tentang kedua kolom. | `a1-u11-o2`, Lesen, respons pertama, bantuan, hasil perbaikan. |
| Dengar perubahan | Gunakan latar peron, tiket lama dan audio perubahan. Selama soal menyimak, angka baru belum tampak pada papan, teks dialog, judul, label pembaca layar otomatis atau nama pilihan yang menandai jawaban benar. Transkrip bisa diminta. Sesudah pemain menjawab, buka papan baru. | `a1-u11-o4`, Hören, varian klip, pilihan, jumlah putar ulang dan penggunaan transkrip. |
| Tanya petugas | Sediakan *Rekam jawaban*, *Dengarkan rekaman*, *Ulangi*, dan *Gunakan teks*. Minta izin mikrofon saat pemain memilih rekam. Terima pertanyaan wajar tentang jalur. Beri satu pertanyaan balik yang relevan. Tanpa penilai lisan yang teruji, tandai rekaman “menunggu telaah”. | Simpan mode respons sebenarnya. Penolakan izin mikrofon tetap memungkinkan cerita lanjut. Jawaban ketik tidak menghasilkan bukti lisan. |
| Tulis pesan | Hubungkan ke Bab 12. Minta pemain memberi tahu Mia kapan dan di mana akan bertemu berdasarkan keadaan terakhir. Contoh kriteria: penerima dapat mengenali waktu serta tempat, ujaran dapat dipahami, dan isi sesuai keputusan sesi. Terima susunan kata alternatif. Sorot satu hal untuk diperbaiki. | `a1-u12-o5`, Schreiben, teks awal, revisi, bantuan, status telaah. |
| Coba situasi baru | Ganti tiket, waktu, atau peron dan klip yang sesuai. Jalankan dengan pertanyaan baru, lalu buka ringkasan empat keterampilan. | Tautkan bukti ke ID stimulus baru. Putar ulang kasus yang sama tetap berstatus latihan ulang. |

**Tiga ruang belajar.** *Main cerita* mengutamakan interaksi dengan bantuan. *Latih keterampilan* memberi tugas baru dengan dukungan opsional. *Simulasi ujian* memakai set dan aturan profil Goethe dewasa yang dipilih. Pakai [spesifikasi ujian](../Visual-Novel-dan-Persiapan-Ujian.md) untuk durasi tiap tingkat, batas bantuan dan rubrik. Set A1 lama berdurasi 33 menit diberi label *Latihan singkat A1*. Pada pilot, pertahankan akses set yang tersedia dan bedakan hasilnya dari simulasi penuh. Untuk produksi simulasi penuh, verifikasi versi format dengan sumber resmi dan pengajar.

## 7. Arahan kode, data dan ketahanan

- **Stack.** Ikuti React, TypeScript, Vite, Tauri 2 dan SQLite serta pola di repo. Baca AGENTS.md lokal, package.json, lockfile dan konfigurasi sebelum menginstal. Periksa apakah modul `TitleScreen`, `Stage`, `DialogPanel`, `AudioController`, `engine/story`, `engine/matchers`, `engine/evaluate` dan penyimpanan progres sudah menyediakan perilaku yang dibutuhkan. Perbaiki kode di jalur aktif. Pertahankan akses fungsi lama melalui navigasi yang jelas.
- **Skenario sebagai sumber fakta.** Gunakan satu rekaman skenario untuk angka peron, waktu, jawaban yang diterima, properti sebelum/sesudah, dan klip yang cocok. Jangan menyimpan angka yang sama secara independen di empat komponen. Pisahkan data pelajaran, keadaan permainan, pemutar media, penilaian dan tampilan sejauh yang dibutuhkan.
- **Bukti percobaan.** Gunakan struktur lama jika mewakili data berikut: ID percobaan, tujuan, level, keterampilan, mode, lokasi/penutur, stimulus dan versi, jenis respons, bantuan, transkrip, hasil serta telaah. Simpan kemajuan cerita secara terpisah. Jawaban salah dan perbaikannya tetap dapat dibedakan. Latihan dengar dengan transkrip tidak diberi status menyimak mandiri.
- **Simpan dan lanjutkan.** Pulihkan avatar, nama, node, pilihan bermakna, keadaan properti, draf yang sedang ditulis dan preferensi. Pemberian surat atau pengiriman pesan hanya terjadi sekali walau klik ganda atau aplikasi dimuat ulang. Pertahankan profil lama yang belum memiliki characterId. Simpan sebelum/selama transisi dengan cara konsisten sehingga hasil sebelumnya tidak hilang.
- **Privasi.** Progres dan rekaman peserta berada pada perangkat secara default. Berikan kontrol putar/hapus bagi rekaman sendiri. Jalankan QA dengan data fiktif pada profil terisolasi. Jangan mengirim nama, rekaman, database pengguna atau keluaran QA privat ke repositori publik.
- **Windows dan web.** Windows offline adalah target produk. Gunakan SQLite desktop melalui layanan yang ada. Jika platform agen hanya mendukung web, buat pratinjau yang benar-benar bisa dimainkan memakai penyimpanan browser di balik kontrak yang sama; periksa reload. Laporkan hasil web dan status Windows secara terpisah. Rute media harus bekerja di lokasi deployment yang dipilih. Pada pilot lokal, hindari ketergantungan ke CDN, jalur absolut komputer pembuat, dan layanan TTS berbayar.
- **Build dan jalur uji.** Gunakan perintah repo yang cocok dengan checkout. Pada konfigurasi yang diperiksa tersedia `pnpm install`, `pnpm build`, `pnpm tauri dev`, dan `pnpm tauri build`. Jalankan regresi yang relevan untuk latihan, resume dan seed, lalu tes baru untuk kegagalan khusus di bawah. Catat perintah nyata beserta hasilnya. Pada Windows, buka EXE kandidat dengan profil QA, maksimum satu instance per agen, lalu tutup instance uji. Jangan menimpa aplikasi terpasang atau pintasan pengguna. Serahkan hasil lokal untuk peninjauan.

## 8. Uji penerimaan yang harus dapat diulangi pemeriksa lain

| ID | Tindakan penguji | Kriteria lulus |
|---|---|---|
| U01 | Buka kandidat dari pintu masuk normal dengan profil baru. | Judul Arena muncul. Mulai mengarah ke pemilihan karakter. |
| U02 | Uji semua empat avatar, putar “Hallo!”, lalu pilih tokoh lain saat suara pertama berjalan. | Empat potret asli tampil; suara sesuai ID; suara pertama berhenti. Tokoh terpilih muncul di adegan berikutnya. |
| U03 | Jawab Mia dengan sapaan saja, nama saja, kalimat penuh, lalu gunakan bantuan pada percobaan lain. | Cabang dan catatan hasil sesuai respons; nama saja memajukan percakapan tanpa mendapat kredit kalimat penuh. |
| U04 | Ganti giliran, buka riwayat, tekan bisu, lalu tinggalkan adegan saat tutor berbicara. | Audio dan mulut kembali diam; kembali ke adegan tidak memutar dua klip. |
| U05 | Mainkan tiket dan pengumuman Bab 11, pilih peron lama, lalu perbaiki. | Sebelum menjawab tidak ada bocoran peron baru. Peron pada audio, umpan balik dan papan akhir konsisten. Hasil pertama tersimpan. |
| U06 | Ulang klip, buka transkrip, lalu coba lagi dengan klip sengaja gagal dimuat pada lingkungan uji. | Putar ulang, bantuan teks dan kegagalan teknis dibedakan; jalur senyap tetap dapat digunakan. |
| U07 | Tolak izin mikrofon, lalu pada profil uji lain rekam jawaban, dengarkan dan hapus. | Jalur mengetik tetap berjalan; hanya sampel yang benar-benar direkam masuk aktivitas lisan; penghapusan dapat diperiksa. |
| U08 | Tulis pesan dengan waktu salah, revisi memakai susunan kalimat lain yang wajar. | Umpan balik menyasar informasi yang salah; teks awal dan revisi tercatat; pesan cocok dengan keputusan sesi. |
| U09 | Berhenti di tengah giliran, buka ulang lalu tekan tombol lanjut dua kali cepat. | Nama, avatar, draf dan posisi pulih. Satu jawaban menghasilkan satu peristiwa. |
| U10 | Jalankan stimulus transfer dan cek jurnal. | Jurnal menunjukkan keterampilan dan bantuan sebenarnya; tugas baru terpisah dari pengulangan. Hasil tulis/lisan yang belum ditelaah diberi status sesuai. |
| U11 | Uji 900×600 dan 1280×800, Tab/Enter/Escape, minim gerak, terjemahan terbuka. | Pertanyaan dan tombol aksi dapat dijangkau, fokus kembali benar, kontrol modal berfungsi dan pemain dapat melanjutkan tanpa audio. |
| U12 | Buka salinan profil lama, pustaka A1–B2, latihan singkat A1 dan satu target lanjutkan. Jalankan kandidat desktop tanpa jaringan. | Data lama dapat dipakai, label latihan tepat, aset lokal tersedia. Catat hasil browser secara terpisah jika ada. |

Untuk setiap baris berikan **Lulus**, **Gagal**, atau **Belum diuji**, berikut identitas kandidat dan lokasi bukti. Sertakan tangkapan layar dari awal, satu cuplikan pergantian penutur, bukti pengumuman/peron, satu contoh jurnal dan satu uji setelah aplikasi dibuka ulang. Tes otomatis, keberhasilan decode, bukti pemutaran runtime dan penilaian pengajar mengukur hal yang berbeda. Tandai mana yang benar-benar dilakukan.

## 9. Laporan akhir yang saya perlukan

1. **Cara mencoba.** Beri lokasi EXE dan hash SHA-256 untuk kandidat Windows, atau URL pratinjau beserta batasnya. Sertakan langkah singkat “Mulai → pilih avatar → jawab Mia” dan “Latih keterampilan → Peron berubah → tulis pesan → jurnal”.
2. **Apa yang berubah.** Sebut commit dasar, identitas revisi hasil, file penting, apa yang digunakan ulang, dan bagaimana kandidat menemukan aset ketika dipindahkan. Beri satu contoh pemetaan lengkap giliran dialog → tokoh → frame → audio → aturan respons → bukti belajar.
3. **Bukti dan kekurangan.** Isi U01–U12. Laporkan kegagalan, dampaknya ke pelajar dan pekerjaan tersisa. Nyatakan siapa yang perlu menelaah bahasa, suara, tulisan atau rekaman sebelum mengklaim mutu pembelajaran.
4. **Penerusan.** Urutkan pekerjaan berikut: menyelesaikan 12 bab/36 pelajaran/60 tujuan A1; A2 unit 101 tentang janji perbaikan rumah; B1 unit 201 tentang rapat tetangga; B2 unit 302 tentang konsultasi publik; lalu perluasan ke seluruh unit masing-masing. Siapkan model konten bagi C1/C2; “C3 — Jalur Pakar Lernen” adalah jalur internal sesudah C2. Untuk tiap paket lanjutan cantumkan ketergantungan, aset tersedia, satu stimulus baru dan keterampilan yang harus dibuktikan.
5. **Keputusan untuk direktur.** Ringkas dalam tiga baris: apa yang bisa dicoba sekarang, masalah terpenting yang masih terasa saat bermain, dan perbaikan berikut yang paling meningkatkan kemampuan pelajar. Akhiri dengan hasil yang tersedia meski satu platform atau media masih terhambat.
