# Bab 12 · Sekarang kamu yang menyambut

**Materi:** Komunikasi & janji. **Pemeran adegan:** Mia, Eva, pendatang baru. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Kalender bercabang, telepon, kartu cangkir, buku tamu.

## Adegan 1 · Einladen und verabreden

Ruang warga. Buku tamu yang dulu hanya berisi satu nama kini hampir penuh. Pilih waktu untuk menyambut seorang pendatang baru.

**Mia** — „Erinnerst du dich an deinen ersten Brief?“  
*Kamu ingat surat pertamamu?*

**Materi tutor yang dapat dibuka:** Membuat ajakan • Menyepakati waktu • Menerima dan membatalkan.  
**Kosakata sumber:** Anruf, SMS, Besuch, Kontakt, Telefonat, Briefumschlag, Briefmarke, Faxgerät. **Latihan asal:** D10.

### Mengundang dan menyepakati waktu · `a1-u12-o1`

**Frau Lehmann, latihan bersama.** einladen dan mitkommen dapat dipisah. Untuk waktu bersama tanyakan «Um wie viel Uhr treffen wir uns?»

**Mia** — „Wir öffnen morgen den Raum. Wen lädst du ein?“  
*Besok kita membuka ruang warga. Siapa yang kamu undang?*

**Giliran pemain.** Sampaikan ajakan «Ich lade dich ein. Kommst du mit?» Tanyakan jam dan sepakati «Wir treffen uns um vier Uhr.»

**Jika maksud tersampaikan.** Pendatang menerima usulan waktu. Simpan sebagai usulan hingga kedua pihak sepakat.

**Jika butuh bantuan.** Jika tempat ada tetapi jam kosong, biarkan kartu terbuka. Ulang dengan janji pagi pada jam baru.

### Menerima atau menolak ajakan dan mengusulkan waktu lain · `a1-u12-o2`

**Frau Lehmann, latihan bersama.** Jika bentrok, tolak dengan sopan dan usulkan satu waktu konkret. Jika cocok, respons singkat sudah wajar.

**Tamu** — „Hast du am Samstag Zeit?“  
*Sabtu kamu punya waktu?*

**Giliran pemain.** Kartu penuh Sabtu. «Leider kann ich nicht. Können wir uns am Sonntag treffen?» Pada jadwal kedua yang cocok «Gern, ich komme.»

**Jika maksud tersampaikan.** Tamu menggeser penanda ke hari yang disepakati bersama.

**Jika butuh bantuan.** Jika menolak tanpa pengganti saat tugas meminta janji, tunjuk hari kosong. Ulang dengan Selasa dan Rabu.

## Adegan 2 · Am Telefon

Telepon di meja. Tamu meminta bicara dengan Mia yang sedang di luar. Catat pesan dan janjikan panggilan kembali.

**Materi tutor yang dapat dibuka:** Memulai percakapan telepon • Verba pisah anrufen • Mencatat pesan.  
**Kosakata sumber:** Briefumschlag, Briefmarke, Faxgerät, Terminkalender, Rückruf, Reservierungsnummer, Verabredung, Postkarte. **Latihan asal:** D3.

### Memulai percakapan telepon · `a1-u12-o3`

**Frau Lehmann, latihan bersama.** Saat menelepon, kenalkan diri dengan hier ist …; minta bicara memakai mit dan tangguhkan dengan Einen Moment bitte.

**Tamu** — „Guten Tag, hier ist Eva. Kann ich bitte mit Mia sprechen?“  
*Selamat siang, ini Eva. Bolehkah saya berbicara dengan Mia?*

**Giliran pemain.** Jawab «Guten Tag, hier ist {nama}. Einen Moment bitte.» Kemudian tukar peran dan minta bicara dengan Mia.

**Jika maksud tersampaikan.** Tamu menunggu; pemain melihat kursi Mia yang kosong.

**Jika butuh bantuan.** Jika langsung menutup telepon, putar ulang permintaan penelepon. Coba panggilan baru untuk Herr Bauer «mit Herrn Bauer».

### Memakai anrufen pisah dan meninggalkan pesan · `a1-u12-o4`

**Frau Lehmann, latihan bersama.** anrufen terpisah. Jika orangnya tidak ada, tawarkan atau minta meninggalkan pesan.

**Tamu** — „Mia ist nicht da? Kann ich eine Nachricht hinterlassen?“  
*Mia tidak ada? Bolehkah saya meninggalkan pesan?*

**Giliran pemain.** «Ja, gern.» Dengarkan «Bitte ruf mich am Sonntag an.» Catat siapa dan kapan. Sebagai Mia jawab «Ich rufe dich am Sonntag an.» Susun permintaan meninggalkan Sprachnachricht.

**Jika maksud tersampaikan.** Nama penelepon dan hari tercatat pada satu pesan sehingga Mia tahu harus menghubungi siapa.

**Jika butuh bantuan.** Jika memanggil nama yang salah, dengarkan identitas penelepon. Ulang dengan waktu Senin dan pesan suara baru.

**Dialog transisi.** Jika hari lain disepakati, ganti nama hari dengan nilai dari kalender.

**Eva, melalui telepon** — „Danke. Dann höre ich am Sonntag von euch.“  
*Terima kasih. Kalau begitu aku menunggu kabar kalian hari Minggu.*

## Adegan 3 · Eine Nachricht schreiben

Meja tulis dan kotak pos. Ada kartu dengan gambar cangkir kosong, sama seperti surat pertamamu. Sekarang giliranmu menulis ajakan.

**Materi tutor yang dapat dibuka:** Pesan tertulis sederhana • E-Mail dan surat • Membalas dan mengonfirmasi.  
**Kosakata sumber:** Reservierungsnummer, Verabredung, Postkarte, Sprachnachricht, Handynummer, Anruf, SMS, Besuch. **Latihan asal:** D6.

### Menulis dan membalas pesan sederhana · `a1-u12-o5`

**Frau Lehmann, latihan bersama.** Pesan singkat perlu penerima, waktu, tempat dan penutup. Gunakan Briefumschlag untuk amplop, Briefmarke untuk prangko.

**Mia** — „Unser Gast kennt den neuen Termin noch nicht. Schreibst du ihm?“  
*Tamu kita belum tahu jadwal yang baru. Maukah kamu menulis kepadanya?*

**Giliran pemain.** Tulis berdasarkan jadwal hasil rundingan. Contoh «Hallo Eva, danke für deine Nachricht. Ich bestätige den Termin. Wir treffen uns am Sonntag um vier Uhr im Café. Bis bald! {nama}» Lalu pilih amplop dan prangko untuk versi surat dalam amplop (kartu pos cukup diberi prangko).

**Jika maksud tersampaikan.** Kartu terkirim dan jawaban tamu menyebut waktu serta tempat yang sama. Cangkir pada kartu kini memuat tanda tangan pemain.

**Jika butuh bantuan.** Jika pesan berbeda dari kalender, tandai bagian waktu untuk diperbaiki. Coba kirim surel singkat untuk waktu dan tempat baru.

## Contoh cabang saat maksud belum jelas

**Eva** — „In meiner Nachricht steht ein anderer Tag. Wann treffen wir uns denn?“  
*Di pesanku tertulis hari lain. Jadi kita bertemu kapan?*

Buka jadwal kesepakatan. Perbaiki hanya isi yang berbeda lalu kirim kembali.

## Pertemuan mandiri

Baca jadwal tamu baru, negosiasikan waktu, terima telepon, lalu kirim konfirmasi tertulis yang konsisten. Akhiri dengan sapaan untuk tamu.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Pendatang membuka kartu dan bertanya «Wie heißt du?». Pemain menjawab dengan nama pilihannya. Mia menutup buku tamu. Jurnal menunjukkan keterampilan mandiri dan yang bisa diulang.

**Pendatang baru** — „Hallo! Ich bin neu hier. Wie heißt du?“  
*Halo! Aku baru di sini. Siapa namamu?*

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u12-o1` | 1 | 1 |
| `a1-u12-o2` | 1 | 1 |
| `a1-u12-o3` | 2 | 2 |
| `a1-u12-o4` | 2 | 2 |
| `a1-u12-o5` | 3 | 3 |

**Bacaan katalog Arena:** belum ada bacaan bertag unit ini pada katalog A1 yang diperiksa. Gunakan naskah bab dan materi unit sebagai aktivitas inti.

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 12](../../src/data/lessons/a1_unit12_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
