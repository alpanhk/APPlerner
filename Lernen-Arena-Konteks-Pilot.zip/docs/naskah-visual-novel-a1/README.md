# Buku naskah Lernen A1 · Buku tamu bergambar cangkir

Draf produksi cerita visual novel untuk penulis, pengajar, pengembang, ilustrator dan pengisi suara. Mulai dari surat Mia di akhir prolog. Setiap bab mengubah apa yang dapat dilakukan pemain di lingkungan barunya. Di bab terakhir, pemain menyambut pendatang dengan undangannya sendiri.

## Daftar bab

| Unit | Naskah | Materi |
|---|---|---|
| 01 | [Tanda cangkir di balik surat](bab-01.md) | Salam & perkenalan diri |
| 02 | [Jam yang terlipat](bab-02.md) | Angka, waktu, harga |
| 03 | [Siapa di foto ini?](bab-03.md) | Keluarga & hubungan |
| 04 | [Dua cangkir, satu meja](bab-04.md) | Makanan & minuman |
| 05 | [Jaket yang tertukar](bab-05.md) | Belanja & harga |
| 06 | [Kunci ruang bersama](bab-06.md) | Rumah & tempat tinggal |
| 07 | [Peta untuk tamu yang tersesat](bab-07.md) | Kota & petunjuk arah |
| 08 | [Giliran pertama](bab-08.md) | Pekerjaan & kegiatan harian |
| 09 | [Suara Mia serak](bab-09.md) | Kesehatan & tubuh |
| 10 | [Satu kursi kosong di klub](bab-10.md) | Waktu luang & hobi |
| 11 | [Peron berubah](bab-11.md) | Transportasi & perjalanan |
| 12 | [Sekarang kamu yang menyambut](bab-12.md) | Komunikasi & janji |

## Cara memainkan satu bab

1. **Tiba.** Layar menampilkan satu situasi, orang yang perlu diajak bicara, dan tujuan singkat. Contoh di kios: “Ambil peti yang sesuai dengan anggaranmu.” Pertahankan buku tamu, jam janji, atau properti yang relevan antara adegan.
2. **Belajar bersama Frau Lehmann.** Tampilkan materi sedikit demi sedikit. Tutor membacakan contoh Jerman dengan terjemahan opsional dan memberi kesempatan meniru. Pemain dapat membuka semua topik pelajaran yang tertulis pada header adegan. Untuk isi, contoh, rangkuman, kosakata, dan latihan yang telah tersedia, pakai unit dan nomor pelajaran yang sama pada sumber.
3. **Berbicara dengan NPC.** Mainkan satu ujaran, tampilkan keadaan dunia yang diperlukan (misalnya label harga atau jadwal) lalu beri giliran. Contoh jawaban dalam naskah merupakan pegangan penulis dan penguji. Di layar pemain, contoh lengkap muncul hanya atas permintaan. Latihan awal boleh menggunakan pilihan. Saat menilai kemampuan menyusun ujaran, sediakan susun kata atau ketik bebas. Tugas mendengar menyediakan putar ulang dan jalur transkrip.
4. **Melihat akibatnya.** Tokoh melakukan satu hal yang masuk akal dari jawaban. Penjual memberi barang yang diminta, jadwal berubah jika kedua pihak sepakat, amplop tetap di tangan ketika penerima belum jelas. Dialog koreksi memberi satu kesempatan memperjelas maksud. Terima respons komunikatif yang berbeda dari contoh jika data, register dan sasaran tugas cocok.
5. **Mencoba mandiri.** Ganti lawan bicara atau stimulus dan sembunyikan contoh. Jurnal merekam per tujuan: belum dicoba, berhasil dengan bantuan, berhasil mandiri. Meniru tutor belum cukup untuk status mandiri. Permintaan bantuan memberi hasil berbantuan pada percobaan tersebut. Mengulang suara asli atau menggunakan akses keyboard tetap tersedia. Jika tugas yang diukur khusus menyimak, bedakan bukti dengar dan baca transkrip. Nama saja dapat memajukan cerita saat wajar tetapi belum menguji bentuk perkenalan lengkap. Sediakan tantangan singkat baru untuk tujuan yang masih memerlukan latihan; izinkan pemain mengunjungi ulang bab dan menyimpan kemajuannya.

## Kontinuitas cerita dan arahan produksi

- Urutan utama mengikuti 12 unit. Titik sambung prolog adalah `e_letter` menuju `e_end` di ekspor Arena. Bila progres lama hanya menyimpan akhir prolog, buka Bab 01 pada pagi berikutnya dan tampilkan jurnal awal apa adanya. Jangan memberikan nilai mandiri berdasarkan status telah membuka surat.
- Pertahankan pemain pilihan pengguna, Frau Lehmann, Mia, Herr Bauer dan petugas pos dari prolog. Peran tambahan tercantum di awal tiap bab. Aset tambahan dalam naskah adalah kebutuhan produksi. Pemeran pendukung dapat hadir sebagai suara dari balik loket ketika potret belum siap untuk prototipe. Gunakan satu identitas tetap untuk satu tokoh lintas bab.
- Gunakan potret statis. Hanya mulut penutur yang berpindah frame saat ada suara. Potret kembali tertutup saat audio selesai, dijeda atau adegan ditinggalkan. Pemain mengendalikan kapan lanjut. Pergantian lokasi memakai transisi pendek. Dalam mode minim gerak, gunakan potongan langsung. Tampilkan petunjuk visual untuk bel, telepon, atau pengumuman. Pastikan giliran dan informasi penting dapat dibaca dalam mode senyap.
- Pisahkan baris Jerman, terjemahan, arahan panggung, dan jawaban acuan sebelum perekaman. Penutur sebenarnya dicetak tebal di naskah. Materi Frau Lehmann berupa panduan pengajaran dalam bahasa Indonesia dengan contoh Jerman terpisah. Nama bebas, pilihan barang, jadwal, dan tujuan perjalanan mengambil nilai dari sesi. Contoh tertulis memakai satu jalur cerita yang konsisten. Render variasi pada teks dan pastikan klip tetap cocok, atau gunakan baris suara netral yang sesuai. Simpan kedelapan suara inti yang sudah dipesan untuk pemerannya masing-masing sesuai manifest produksi.
- Simpan bab, adegan, giliran terakhir, barang, keputusan dan bukti per tujuan. Setelah memuat ulang, penerimaan barang atau pengiriman kartu yang sudah dikonfirmasi berlaku satu kali. Untuk naskah rekaman, bentuk ID dari bab, adegan, ID tujuan, dan fungsi ujaran agar baris milik NPC dan balasan pemain dapat dilacak.

## Cakupan dan penelaahan

Sumber pembelajaran tersedia dalam [12 unit A1](../../src/data/lessons/units_a1.json) dan [inventaris 60 tujuan](../../src/data/lessons/a1_objectives.json). Naskah menghubungkan 36 pelajaran dan 122 topik slide ke adegan lewat nomor pelajaran. Lima interaksi utama per bab masing-masing memiliki ID tujuan asli, ujaran, giliran pemain, konsekuensi dan bantuan. Tujuan yang dipakai di beberapa pelajaran dicatat pada tabel akhir bab. Latihan sumber serta checkpoint tetap bisa dipakai pada jurnal belajar. Bacaan pilihan mengikuti 18 entri A1 pada katalog Arena yang diperiksa. Unit 10–12 tetap mempunyai materi dan adegan lengkap meskipun katalog tersebut belum memberi ketiganya bacaan A1 bertag unit masing-masing.

**Urutan uji yang disarankan.** Mulai dari akhir prolog dan jalankan Bab 01. Coba jalur salah harga di Bab 02, pisah tagihan di Bab 04, perubahan jalur kereta di Bab 11, serta negosiasi dan konfirmasi ulang di Bab 12. Pada setiap bab, cocokkan seluruh lima ID tujuan, cek satu jawaban setara, satu bantuan, satu variasi mandiri, dan satu muat ulang. Untuk penelaahan bahasa, pengajar memeriksa register du/Sie, kewajaran ujaran, rentang jawaban yang diterima, serta tingkat kesulitan sebelum rekaman final. Paket ini menyiapkan naskah; validasi pengajar dan uji pemain dilakukan pada tahap berikutnya.
