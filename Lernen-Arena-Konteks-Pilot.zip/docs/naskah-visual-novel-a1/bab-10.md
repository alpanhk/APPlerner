# Bab 10 · Satu kursi kosong di klub

**Materi:** Waktu luang & hobi. **Pemeran adegan:** Herr Bauer, Mia, petugas klub. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Kartu anggota, kalender, lambang klub.

## Adegan 1 · Hobbys und Vorlieben

Papan klub. Ada klub musik, kartu, renang, dan jalan kaki. Herr Bauer menyimpan satu kursi untuk tamu, tetapi tidak tahu kegiatan favoritmu.

**Herr Bauer** — „Bei uns ist noch ein Platz frei.“  
*Di tempat kami masih ada satu tempat kosong.*

**Materi tutor yang dapat dibuka:** gern dan lieber • Kata kerja untuk hobi • Mengungkapkan kesukaan.  
**Kosakata sumber:** Schachspiel, Theaterstück, Wanderung, Malerei, Kamera, Spielkarte, Sporthalle, Musikgruppe. **Latihan asal:** D2.

### Menyatakan kesukaan dengan gern/lieber/am liebsten · `a1-u10-o1`

**Frau Lehmann, latihan bersama.** gern menyatakan suka, lieber lebih suka, am liebsten paling suka. Urutkan menurut selera karakter.

**Mia** — „Was machst du am liebsten?“  
*Apa yang paling kamu sukai?*

**Giliran pemain.** Dengan kartu preferensi, «Ich spiele gern Karten, ich schwimme lieber, und am liebsten mache ich Musik.» Atau gunakan urutan pilihan sendiri yang konsisten.

**Jika maksud tersampaikan.** Mia memindahkan penanda ke papan kegiatan favoritmu.

**Jika butuh bantuan.** Jika tiga tingkat tertukar, gunakan satu sampai tiga hati. Ulang dengan urutan kegiatan baru.

### Menyebut hobi dan kegiatan waktu luang · `a1-u10-o2`

**Frau Lehmann, latihan bersama.** Perhatikan verba yang cocok, misalnya Musik machen, Karten spielen, schwimmen gehen dan wandern gehen.

**Herr Bauer** — „Am Samstag wollen wir wandern gehen. Kommst du mit?“  
*Sabtu kami mau mendaki. Kamu ikut?*

**Giliran pemain.** Pilih ikon kegiatan yang didengar dan sebutkan keempat kegiatan pada jadwal. «Heute spielen wir Karten. Am Samstag gehen wir wandern.»

**Jika maksud tersampaikan.** Jadwal berganti ke kegiatan yang dipilih.

**Jika butuh bantuan.** Jika memilih berenang, putar ulang kata wandern. Coba menceritakan kegiatan musik dan renang.

## Adegan 2 · Freizeit planen

Bangku dekat lapangan. Mia hanya luang pada satu dari dua waktu. Atur pertemuan yang benar-benar bisa kalian hadiri.

**Materi tutor yang dapat dibuka:** Mengajak teman • Menerima atau menolak ajakan • Urutan waktu.  
**Kosakata sumber:** Spielkarte, Sporthalle, Musikgruppe, Probe, Wochenendausflug, Brettspiel, Tanzkurs, Musikfestival. **Latihan asal:** D6.

### Mengajak teman dan merespons ajakan · `a1-u10-o3`

**Frau Lehmann, latihan bersama.** Ajakan boleh diterima atau ditolak sesuai kalender. Wollen wir …? meminta keputusan bersama.

**Mia** — „Hast du am Freitag Zeit? Wollen wir Karten spielen?“  
*Jumat kamu ada waktu? Mau bermain kartu?*

**Giliran pemain.** Kalender penuh Jumat. «Leider kann ich nicht. Hast du am Samstag Zeit?» Jika jadwal cocok, «Gern!» atau «Das klingt gut!»

**Jika maksud tersampaikan.** Mia mempertahankan atau memindahkan janji sesuai jawaban.

**Jika butuh bantuan.** Jika menerima saat bentrok, perlihatkan janji lama. Coba skenario dengan Jumat kosong dan buat ajakan sendiri.

### Menyebut jadwal kegiatan dengan am dan um · `a1-u10-o4`

**Frau Lehmann, latihan bersama.** Letakkan am sebelum hari dan um sebelum jam. Saat waktu di depan, verba tetap posisi kedua.

**Mia** — „Wann beginnt unser Training?“  
*Kapan latihan kita mulai?*

**Giliran pemain.** Jadwal Sabtu 16.00. «Am Samstag beginnt das Training um sechzehn Uhr.» Atau «Um sechzehn Uhr beginnt das Training.»

**Jika maksud tersampaikan.** Mia menuliskan waktu yang sama di kedua kalender.

**Jika butuh bantuan.** Jika memilih jam tutup, sorot waktu mulai. Ulang untuk jadwal Selasa pukul lima.

**Dialog transisi.**

**Mia** — „Freitag geht nicht. Aber Samstag passt gut!“  
*Jumat tidak bisa. Tapi Sabtu cocok!*

## Adegan 3 · Im Verein

Meja anggota. Kartu jadwal ada dua sisi. Isi frekuensi, rekan latihan dan jadwal yang sesuai dengan klub pilihan skenario.

**Materi tutor yang dapat dibuka:** Menjadi anggota • Jadwal latihan • Aktivitas dalam klub.  
**Kosakata sumber:** Brettspiel, Tanzkurs, Musikfestival, Musikinstrument, Lesung, Schachspiel, Theaterstück, Wanderung. **Latihan asal:** D3.

### Membicarakan keanggotaan klub dan jadwal latihan · `a1-u10-o5`

**Frau Lehmann, latihan bersama.** Pakai Mitglied im Verein, einmal/zweimal pro Woche, dan mit + Dativ untuk rekan kegiatan.

**Petugas klub** — „Wie oft trainierst du? Und mit wem?“  
*Seberapa sering kamu berlatih? Dengan siapa?*

**Giliran pemain.** Kartu Selasa dan Jumat dengan Mia. «Ich bin Mitglied im Verein. Ich trainiere zweimal pro Woche mit meiner Freundin.»

**Jika maksud tersampaikan.** Petugas memberi kartu anggota dengan dua giliran.

**Jika butuh bantuan.** Jika hanya menyebut dua hari, minta rangkum frekuensi. Ulang dengan sekali seminggu bersama seorang teman laki-laki.

**Dialog transisi.**

**Mia** — „Eine Einladung aus Leipzig! Nimmst du unser Buch mit?“  
*Ada undangan dari Leipzig! Kamu mau membawa buku kita?*

## Contoh cabang saat maksud belum jelas

**Mia** — „Am Freitag habe ich keine Zeit. Geht es auch am Samstag?“  
*Jumat aku tidak ada waktu. Bisa Sabtu juga?*

Tahan konfirmasi sampai kedua kalender cocok. Terima usulan lain jika sama-sama luang.

## Pertemuan mandiri

Dengan kalender baru, tolak satu ajakan secara sopan, tawarkan jam lain, lalu jelaskan seberapa sering dan dengan siapa kamu berlatih.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Sebuah klub di kota lain mengundang kalian membawa buku tamu untuk dipamerkan. Kalian perlu mencari kereta.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u10-o1` | 1 | 1 |
| `a1-u10-o2` | 1 | 1 |
| `a1-u10-o3` | 2 | 2 |
| `a1-u10-o4` | 2 | 2 |
| `a1-u10-o5` | 3 | 3 |

**Bacaan katalog Arena:** belum ada bacaan bertag unit ini pada katalog A1 yang diperiksa. Gunakan naskah bab dan materi unit sebagai aktivitas inti.

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 10](../../src/data/lessons/a1_unit10_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
