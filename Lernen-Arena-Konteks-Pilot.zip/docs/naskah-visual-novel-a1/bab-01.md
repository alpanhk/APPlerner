# Bab 01 · Tanda cangkir di balik surat

**Materi:** Salam & perkenalan diri. **Pemeran adegan:** Mia, Herr Bauer, tamu. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Surat, buku tamu, foto, peta asal/tinggal.

**Titik masuk:** sesudah pemain membuka surat di akhir prolog. Pertahankan nama, avatar, dan riwayat bantuan. Pada profil baru, jalankan prolog dahulu. Pemain yang telah membuktikan keterampilan sapaan atau nama dapat langsung mengerjakan variasi formalnya.

## Adegan 1 · Hallo! Ich heiße …

Ambang rumah, keesokan pagi. Pemain membalik surat «Bis morgen!». Di balik gambar cangkir, Mia menggambar bangku di depan kafe. Rupanya ia mengundangmu bertemu di sana.

**Mia** — „Gestern hast du meinen Brief bekommen. Heute schreiben wir deinen Namen ins Buch.“  
*Kemarin kamu menerima suratku. Hari ini kita tulis namamu di buku.*

**Materi tutor yang dapat dibuka:** Sapaan sesuai waktu • Memperkenalkan diri • Bertanya nama • Tiga artikel • Kata ganti & konjugasi.  
**Kosakata sumber:** Name, Mann, Frau, Herr, heißen. **Latihan asal:** D1.

### Menyapa sesuai waktu hari · `a1-u1-o1`

**Frau Lehmann, latihan bersama.** Cocokkan waktu dan lawan bicara. Guten Morgen berlaku pagi, Guten Abend saat bertemu malam, Gute Nacht saat hendak tidur.

**Mia** — „Wir sehen uns morgen früh. Was sagst du dann?“  
*Besok pagi kita bertemu. Kamu akan menyapaku bagaimana?*

**Giliran pemain.** Ucapkan sapaan pagi. «Guten Morgen, Mia!»

**Jika maksud tersampaikan.** Mia melambaikan tangan. Balik kartu ke sore/malam dan pamit kepada petugas secara sopan.

**Jika butuh bantuan.** Bedakan tiba dan berpisah. Ulang dengan kartu siang «Guten Tag», malam «Guten Abend», tidur «Gute Nacht», perpisahan formal «Auf Wiedersehen» dan santai «Tschüs».

### Memperkenalkan dan menanyakan nama · `a1-u1-o2`

**Frau Lehmann, latihan bersama.** Dengan Mia gunakan du, dengan tamu dewasa yang baru dikenal gunakan Sie. Pertanyaan dan jawaban sama-sama penting.

**Tamu** — „Guten Morgen! Ich heiße Eva. Und wie heißen Sie?“  
*Selamat pagi! Nama saya Eva. Siapa nama Anda?*

**Giliran pemain.** Perkenalkan diri «Ich heiße {nama}.» Saat tamu kedua datang, tanyakan «Wie heißen Sie?»; untuk Mia «Wie heißt du?»

**Jika maksud tersampaikan.** Tamu menulis namanya di buku setelah ditanya.

**Jika butuh bantuan.** Nama saja cukup untuk melanjutkan cerita. Untuk bukti belajar ulangi dengan kalimat dan ajukan pertanyaan pada tamu baru.

## Adegan 2 · Woher kommen Sie?

Bangku kafe. Mia ingin membuat buku tamu kecil untuk pertemuan warga. Tulis asal dan tempat tinggal tokoh pilihanmu di halaman pertama.

**Materi tutor yang dapat dibuka:** Kommen aus — asal • Wohnen in — tinggal • Negara & bahasa • Konjugasi kommen • Konjugasi wohnen.  
**Kosakata sumber:** Land, Sprache, Stadt, kommen, wohnen. **Latihan asal:** D3.

### Menyebut asal dan tempat tinggal · `a1-u1-o3`

**Frau Lehmann, latihan bersama.** Woher menanyakan asal, wo menanyakan tempat tinggal. Pada kartu contoh Mia tertulis Berlin dan Leipzig.

**Mia** — „Woher kommst du? Und wo wohnst du jetzt?“  
*Kamu berasal dari mana? Sekarang tinggal di mana?*

**Giliran pemain.** Pakai profil fiktif pada kartu, misalnya «Ich komme aus Indonesien. Ich wohne in Berlin.»

**Jika maksud tersampaikan.** Mia menandai dua tempat berbeda di peta.

**Jika butuh bantuan.** Jika tertukar, tutor menunjuk titik berangkat dan rumah. Kartu baru untuk dua orang «Wir kommen aus Berlin. Wir wohnen in Leipzig.»

**Dialog transisi.**

**Herr Bauer** — „Jetzt weiß ich, wem das Foto gehört.“  
*Sekarang saya tahu foto itu milik siapa.*

## Adegan 3 · Freunde & Alter

Papan foto. Herr Bauer membawa foto tetangga yang keterangannya terlepas. Bantu Mia memasangkan label dan memperkenalkan seorang teman.

**Materi tutor yang dapat dibuka:** Freund & Freundin • Umur • Plural benda • Possessiv mein/meine.  
**Kosakata sumber:** Freund, Freundin, Jahr. **Latihan asal:** D2.

### Menyebut teman dan umur · `a1-u1-o4`

**Frau Lehmann, latihan bersama.** Pakai meine Freundin untuk seorang teman perempuan, mein Freund untuk teman laki-laki. Wie alt menanyakan umur.

**Herr Bauer** — „Wer ist das auf dem Foto? Wie alt ist sie?“  
*Siapa yang ada di foto? Berapa usianya?*

**Giliran pemain.** Kartu Mia, 22. «Das ist meine Freundin Mia. Sie ist zweiundzwanzig Jahre alt.» Kemudian tanya umur temannya.

**Jika maksud tersampaikan.** Herr Bauer menyelipkan keterangan umur di bingkai.

**Jika butuh bantuan.** Jika menamai diri sendiri, sorot orang di foto. Coba foto Leon, 21, dengan «mein Freund».

### Artikel dan bentuk plural · `a1-u1-o5`

**Frau Lehmann, latihan bersama.** Simpan kata bersama artikelnya. der Name, die Frau, das Land. Semua bentuk jamak yang memakai artikel tentu menggunakan die.

**Mia** — „Ein Name steht schon hier. Und auf der zweiten Seite?“  
*Di sini sudah ada satu nama. Bagaimana di halaman kedua?*

**Giliran pemain.** Pasangkan tiga label tunggal, lalu isi dua label jamak «die Namen», «die Freunde».

**Jika maksud tersampaikan.** Mia menempelkan label pada halaman yang tepat.

**Jika butuh bantuan.** Jika artikel benar tetapi jamak keliru, tampilkan pasangan satu–dua. Ulang dengan das Jahr → die Jahre dan das Land → die Länder.

**Dialog transisi.**

**Mia** — „Morgen ist Markt. Kommst du mit?“  
*Besok ada pasar. Kamu ikut?*

## Contoh cabang saat maksud belum jelas

**Herr Bauer** — „Meinen Sie Ihren Wohnort oder Ihren Geburtsort?“  
*Maksud Anda tempat tinggal atau tempat lahir?*

Kembali ke kartu asal/tinggal. Pemain boleh membuka contoh atau menjawab lagi.

## Pertemuan mandiri

Saat penjaga buku berganti, sapa dia dengan Sie, tanyakan namanya, lalu kenalkan teman dari kartu baru. Ia menaruh foto di bawah nama yang benar.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Mia menyelipkan secarik daftar belanja ke buku. Besok kalian akan mencari bahan untuk pertemuan pertama.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u1-o1` | 1 | 1 |
| `a1-u1-o2` | 1 | 1 |
| `a1-u1-o3` | 2 | 2 |
| `a1-u1-o4` | 3 | 3 |
| `a1-u1-o5` | 1, 3 | 3 |

**Bacaan katalog Arena:** *Hallo, ich bin Anna* (textId 1), *Meine Familie* (textId 2), *In der Stadt* (textId 3), *Ein Tag in Berlin* (textId 4)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 1](../../src/data/lessons/a1_unit1_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
