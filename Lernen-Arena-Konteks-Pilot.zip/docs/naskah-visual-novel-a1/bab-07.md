# Bab 07 · Peta untuk tamu yang tersesat

**Materi:** Kota & petunjuk arah. **Pemeran adegan:** Tamu, Mia. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Peta dengan rute alternatif, papan halte.

## Adegan 1 · Orte in der Stadt

Papan peta di alun-alun. Seorang tamu memegang undangan ruang warga. Keterangan petanya pudar, tetapi ia mengenali kantor pos.

**Tamu** — „Guten Tag. Ich bin zum ersten Mal hier.“  
*Selamat siang. Ini pertama kalinya saya di sini.*

**Materi tutor yang dapat dibuka:** Tempat umum • Letak relatif • Kota dan peta.  
**Kosakata sumber:** U-Bahn, Zebrastreifen, Wegweiser, Unterführung, Bürgeramt, Postfiliale, Buchhandlung, Station. **Latihan asal:** D1.

### Menyebut tempat umum di kota dengan artikel · `a1-u7-o1`

**Frau Lehmann, latihan bersama.** Baca lambang peta dengan artikelnya, misalnya das Rathaus, die Post, die Bibliothek, die Apotheke, die Bäckerei.

**Tamu** — „Wo kann ich Brot kaufen?“  
*Di mana saya bisa membeli roti?*

**Giliran pemain.** Tunjuk toko roti, sebut «die Bäckerei». Pasangkan empat lambang sisanya dengan nama dan artikel.

**Jika maksud tersampaikan.** Tamu menempelkan lima label pada peta.

**Jika butuh bantuan.** Jika memilih apotek, tampilkan ikon barang. Ulang dengan membeli perangko dan meminjam buku.

### Menjelaskan letak relatif dengan preposisi Dativ · `a1-u7-o2`

**Frau Lehmann, latihan bersama.** Untuk posisi tetap gunakan Dativ. Di seberang dapat dinyatakan dengan gegenüber der Post.

**Tamu** — „Was liegt zwischen der Post und der Bibliothek?“  
*Apa yang ada di antara kantor pos dan perpustakaan?*

**Giliran pemain.** Pada denah, beri lokasi balai kota «Das Rathaus liegt zwischen der Post und der Bibliothek.» Lengkapi «neben dem Rathaus» dan «gegenüber der Post» untuk dua lokasi lain.

**Jika maksud tersampaikan.** Tamu memberi tanda pada bangunan di tengah.

**Jika butuh bantuan.** Jika memilih gedung yang salah, biarkan dua patokan menyala. Ulang setelah dua lambang bertukar posisi.

## Adegan 2 · Nach dem Weg fragen

Persimpangan. Lonceng trem terdengar sekali. Tamu ingin membeli sesuatu sebelum acara dan menanyakan dua tujuan.

**Materi tutor yang dapat dibuka:** Imperatif formal • Kata arah • Frasa meminta bantuan.  
**Kosakata sumber:** Postfiliale, Buchhandlung, Station, Fußgängerzone, Tiefgarage, Konditorei, Drogerie, Polizeiwache. **Latihan asal:** D9.

### Memberi arahan dengan imperatif formal · `a1-u7-o3`

**Frau Lehmann, latihan bersama.** Saat memberi arahan kepada tamu, pakai bentuk Sie. Sebut titik belok, lalu arah.

**Tamu** — „Ich stehe hier an der Kreuzung. Und jetzt?“  
*Saya di persimpangan. Setelah ini bagaimana?*

**Giliran pemain.** Baca rute bertanda. «Gehen Sie geradeaus. Biegen Sie an der Kreuzung links ab. Nehmen Sie dann die erste Straße rechts.»

**Jika maksud tersampaikan.** Tamu tampil di ujung rute, menunggu konfirmasi tujuan.

**Jika butuh bantuan.** Jika belok terlalu awal, kembali ke persimpangan. Ulang dengan arah pertama ke kanan.

### Menanyakan jalan dengan zum/zur · `a1-u7-o4`

**Frau Lehmann, latihan bersama.** zum berarti zu dem, zur berarti zu der. Pilih sesuai artikel tujuan.

**Mia** — „Du brauchst eine Briefmarke. Frag nach dem Weg!“  
*Kamu memerlukan prangko. Tanyakan jalannya!*

**Giliran pemain.** «Wie komme ich zur Post?» Pada tujuan kedua «Wie komme ich zum Rathaus?» Terima juga permintaan sopan dengan Entschuldigung.

**Jika maksud tersampaikan.** Tamu menunjukkan titik tujuan dan rute pada peta.

**Jika butuh bantuan.** Jika zum dipakai untuk Post, buka label die Post. Coba zur Apotheke dan zum Bahnhof.

**Dialog transisi.**

**Tamu** — „Ah, jetzt sehe ich die Haltestelle.“  
*Ah, sekarang saya melihat haltenya.*

## Adegan 3 · Mit Bus und Bahn

Halte. Mia naik lebih dulu. Pilih kendaraan dan halte yang mendekatkan tamu ke ruang warga.

**Materi tutor yang dapat dibuka:** Transportasi dengan mit • Halte dan parkir • Waktu dan perjalanan.  
**Kosakata sumber:** Konditorei, Drogerie, Polizeiwache, Bushaltestelle, Stadtplan, U-Bahn, Zebrastreifen, Wegweiser. **Latihan asal:** D6.

### Menyebut transportasi dengan mit + Dativ · `a1-u7-o5`

**Frau Lehmann, latihan bersama.** mit diikuti Dativ. Kendaraan fährt saat berjalan dan hält saat berhenti.

**Tamu** — „Wie fahren wir zum Fest? Wo hält die Straßenbahn?“  
*Kita naik apa ke acara itu? Di mana trem berhenti?*

**Giliran pemain.** Pilih rute bergambar trem. «Wir fahren mit der Straßenbahn. Sie hält an der Haltestelle Markt.» Cocokkan mit dem Bus dan mit dem Zug dengan ikon.

**Jika maksud tersampaikan.** Tamu mengikuti pemain turun di halte Markt.

**Jika butuh bantuan.** Jika halte keliru, lihat lambang undangan. Ulang pada bus yang berhenti di Rathaus.

**Dialog transisi.**

**Tamu** — „Morgen brauchen wir Hilfe am Infotisch. Haben Sie Zeit?“  
*Besok kami perlu bantuan di meja informasi. Apakah Anda punya waktu?*

## Contoh cabang saat maksud belum jelas

**Tamu** — „Entschuldigung, links oder rechts an der Kreuzung?“  
*Maaf, di persimpangan belok kiri atau kanan?*

Kembalikan pin ke persimpangan terakhir. Minta satu petunjuk yang dapat dilakukan.

## Pertemuan mandiri

Dari peta alternatif, tanyakan arah ke apotek, pandu tamu dari kantor pos, kemudian beri pilihan trem dan halte akhir.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Tamu tiba dan menawarkan giliran kerja singkat di kantor penyelenggara.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u7-o1` | 1 | 1 |
| `a1-u7-o2` | 1 | 1 |
| `a1-u7-o3` | 2 | 2 |
| `a1-u7-o4` | 2 | 2 |
| `a1-u7-o5` | 3 | 3 |

**Bacaan katalog Arena:** *Der Weg zum Bahnhof* (textId 16), *Ein Nachmittag im Park* (textId 17)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 7](../../src/data/lessons/a1_unit7_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
