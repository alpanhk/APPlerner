# Bab 04 · Dua cangkir, satu meja

**Materi:** Makanan & minuman. **Pemeran adegan:** Mia, pelayan/barista Im Café. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Menu, nampan, tagihan, ilustrasi kafe produksi.

## Adegan 1 · Essen & Trinken

Dapur kafe. Dari balik etalase, Mia melambaikan tangan ke meja yang kosong. Kalian harus memilih kudapan dan minuman sebelum tamu foto datang.

**Mia** — „Da hinten ist ein Tisch am Fenster frei.“  
*Di belakang ada meja kosong di dekat jendela.*

**Materi tutor yang dapat dibuka:** Di meja makan • Buah & sayur • Lauk & bumbu • Rasa & keadaan.  
**Kosakata sumber:** Brot, Käse, Milch, Kaffee, Apfel. **Latihan asal:** D1.

### Menyebut makanan dan minuman dengan artikel · `a1-u4-o1`

**Frau Lehmann, latihan bersama.** Hafalkan artikel bersama bahan. die Milch, das Obst dan das Fleisch lazim dipakai sebagai bahan tanpa menghitung satuan.

**Pelayan** — „Was fehlt noch auf dem Tisch?“  
*Apa yang masih kurang di meja?*

**Giliran pemain.** Baca daftar gambar lalu sebutkan der Käse, die Milch, das Brot. Letakkan das Obst dan das Fleisch di baki sesuai label.

**Jika maksud tersampaikan.** Pelayan menerima baki yang cocok dengan daftar.

**Jika butuh bantuan.** Jika artikel keliru, tutor menyebut satu pasangan. Ulang pada die Butter, der Apfel dan das Wasser.

### Menyatakan rasa dan keadaan lapar/haus · `a1-u4-o2`

**Frau Lehmann, latihan bersama.** hungrig dan durstig menyebut keadaan orang; lecker menyebut rasa makanan.

**Mia** — „Ich habe heute noch nichts getrunken. Und wie schmeckt der Kuchen?“  
*Hari ini aku belum minum. Bagaimana rasa kuenya?*

**Giliran pemain.** Pilih minuman untuk Mia. Katakan «Du bist durstig. Der Kuchen ist lecker.» Kenali tokoh yang berkata «Ich bin hungrig.»

**Jika maksud tersampaikan.** Pelayan membawa air dan memotong kue.

**Jika butuh bantuan.** Jika rasa dipakai untuk orang, tunjuk gelas lalu piring. Ulang dengan sup dan tamu lapar.

## Adegan 2 · Im Restaurant bestellen

Meja dekat jendela, adegan Im Café. Pelayan menunggu pesananmu. Cangkir hanya diletakkan setelah ada pesanan yang cocok.

**Materi tutor yang dapat dibuka:** Memesan dengan sopan • Akkusativ maskulin • Menanyakan & memilih • Membayar.  
**Kosakata sumber:** Wasser, Tee, Saft, bestellen, Rechnung. **Latihan asal:** D4.

### Memesan dengan möchte + Akkusativ · `a1-u4-o3`

**Frau Lehmann, latihan bersama.** Sesudah ich möchte gunakan einen Kaffee, eine Suppe, ein Wasser. bitte melembutkan pesanan.

**Pelayan** — „Guten Tag! Was möchten Sie?“  
*Selamat siang! Anda ingin memesan apa?*

**Giliran pemain.** Pesan sesuai kartu meja «Ich möchte einen Kaffee und eine Suppe, bitte.» Pada kartu tamu kedua tambahkan «ein Wasser».

**Jika maksud tersampaikan.** Cangkir muncul sekali ketika kopi benar-benar dipesan.

**Jika butuh bantuan.** Jika salah barang, pelayan mengonfirmasi «Kaffee oder Tee?» Ulang dengan kartu baru teh dan roti.

### Berinteraksi di restoran · `a1-u4-o4`

**Frau Lehmann, latihan bersama.** Minta menu dan rekomendasi sebelum memesan; zusammen atau getrennt menentukan cara membagi tagihan.

**Pelayan** — „Zusammen oder getrennt?“  
*Bayar bersama atau terpisah?*

**Giliran pemain.** Saat datang ucapkan «Die Speisekarte, bitte. Was empfehlen Sie?» Seusai makan «Die Rechnung, bitte. Getrennt, bitte. Ich zahle mit Karte.»

**Jika maksud tersampaikan.** Pelayan memberi dua tagihan dan mengarahkan terminal pembayaran.

**Jika butuh bantuan.** Jika meminta menu saat hendak membayar, tunjuk urutan peristiwa. Coba pesanan baru dengan satu tagihan tunai.

**Dialog transisi.** Gunakan baris ini hanya bila kedua item cocok dengan pesanan. Untuk kombinasi lain, sebut item yang benar-benar dipesan.

**Pelayan** — „Ein Kaffee für Sie. Und hier ist Ihre Suppe.“  
*Kopi untuk Anda. Dan ini sup Anda.*

## Adegan 3 · Mahlzeiten & Verben

Papan sarapan. Pemilik kafe ingin menyiapkan jamuan berikutnya. Ia menuliskan kebiasaan makan tamu yang kamu sampaikan.

**Materi tutor yang dapat dibuka:** Waktu makan • essen — bentuk tidak beraturan • trinken & kaufen (beraturan) • Kalimat kebiasaan.  
**Kosakata sumber:** Frühstück, Mittagessen, Abendessen, essen, trinken. **Latihan asal:** D6.

### Menyebut waktu makan dan kebiasaan dengan essen/trinken · `a1-u4-o5`

**Frau Lehmann, latihan bersama.** Saat menceritakan kebiasaan, bandingkan ich esse, du isst, sie isst. trinken mengikuti pola biasa.

**Mia** — „Was isst du zum Frühstück? Und was trinkt Leon am Abend?“  
*Apa yang kamu makan saat sarapan? Apa yang Leon minum pada malam hari?*

**Giliran pemain.** Dengan kartu jamuan, jawab «Zum Frühstück esse ich Brot. Zum Mittagessen isst Mia Suppe. Zum Abendessen trinkt Leon Tee.»

**Jika maksud tersampaikan.** Pemilik kafe menyalin kebiasaan ke papan sarapan.

**Jika butuh bantuan.** Jika bentuk esse dipakai untuk semua, tandai subjek. Ulang sebagai pertanyaan «Was isst du?» dan jawaban tokoh baru.

**Dialog transisi.**

**Mia** — „Morgen regnet es. Hast du eine Jacke?“  
*Besok hujan. Kamu punya jaket?*

## Contoh cabang saat maksud belum jelas

**Pelayan** — „Einen Tee oder einen Kaffee? Ich frage lieber noch einmal.“  
*Teh atau kopi? Saya ingin memastikan lagi.*

Kembalikan ke kartu pesanan. Koreksi jumlah/barang sebelum cangkir muncul.

## Pertemuan mandiri

Pesankan teh dan roti untuk seorang tamu baru, tanyakan rekomendasi, lalu bayar terpisah. Sebutkan satu kebiasaan sarapan untuk daftar besok.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Ada undangan membantu meja informasi dalam acara warga. Mia menatap jaket tipismu dan menunjuk ramalan hujan di koran.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u4-o1` | 1 | 1 |
| `a1-u4-o2` | 1 | 1 |
| `a1-u4-o3` | 2 | 2 |
| `a1-u4-o4` | 2 | 2 |
| `a1-u4-o5` | 3 | 3 |

**Bacaan katalog Arena:** *Im Café* (textId 10), *Einkaufen für das Abendessen* (textId 11)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 4](../../src/data/lessons/a1_unit4_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
