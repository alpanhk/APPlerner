# Bab 03 · Siapa di foto ini?

**Materi:** Keluarga & hubungan. **Pemeran adegan:** Mia, Herr Bauer. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Album keluarga fiktif, bingkai, kartu alamat.

## Adegan 1 · Meine Familie

Meja makan Mia. Dua bingkai foto tertukar saat dipindah. Mia mengizinkanmu memakai album keluarganya untuk menemukan pemilik foto.

**Mia** — „Schau mal. Hier war mein Bruder noch ganz klein.“  
*Coba lihat. Di sini saudaraku masih kecil sekali.*

**Materi tutor yang dapat dibuka:** Keluarga inti • Saudara • Kakek, nenek, paman, bibi • mein & meine.  
**Kosakata sumber:** Familie, Mutter, Vater, Kind, Bruder. **Latihan asal:** D1.

### Menyebut anggota keluarga dengan artikel · `a1-u3-o1`

**Frau Lehmann, latihan bersama.** Pelajari label keluarga sebagai satu pasangan bunyi dan gambar, misalnya der Vater, die Mutter, das Kind. Eltern dan Geschwister mengacu pada kelompok.

**Mia** — „Das sind meine Eltern. Wer ist neben meiner Mutter?“  
*Ini orang tuaku. Siapa di sebelah ibuku?*

**Giliran pemain.** Pada bagan fiktif, beri label der Vater, die Mutter, das Kind, die Tante, der Onkel, die Großeltern, die Eltern, die Geschwister.

**Jika maksud tersampaikan.** Mia mengembalikan potret ke cabang keluarga yang sesuai.

**Jika butuh bantuan.** Jika memilih orang tua untuk saudara, sorot satu generasi. Coba bedakan der Großvater dan die Großmutter.

### Memakai mein/meine sesuai gender dan jumlah · `a1-u3-o2`

**Frau Lehmann, latihan bersama.** mein untuk maskulin/netral, meine untuk feminin/jamak saat memperkenalkan subjek.

**Mia** — „Und wer ist das auf deinem Foto?“  
*Lalu siapa yang ada di fotomu?*

**Giliran pemain.** Gunakan kartu keluarga pinjaman. «Das ist mein Bruder. Das ist meine Schwester. Das sind meine Eltern.»

**Jika maksud tersampaikan.** Mia mengenali keluarga kedua dari tiga label itu.

**Jika butuh bantuan.** Jika mein dipakai untuk semua, sorot die Schwester. Ulang dengan mein Kind dan meine Kinder.

## Adegan 2 · Eltern, Geschwister & Status

Dapur Herr Bauer. Satu kartu keluarga bergambar, tanpa info pribadi pemain. Cocokkan jumlah saudara dan keterangan rumah tangga dengan kartu.

**Materi tutor yang dapat dibuka:** Kata yang selalu jamak • Menanyakan jumlah • Status pernikahan • Tinggal bersama.  
**Kosakata sumber:** Eltern, Geschwister, Schwester, verheiratet, ledig. **Latihan asal:** D2.

### Menanyakan dan menyebut jumlah saudara/anak · `a1-u3-o3`

**Frau Lehmann, latihan bersama.** Wie viele meminta jumlah. Setelah haben, ucapkan einen Bruder atau eine Schwester.

**Herr Bauer** — „Wie viele Geschwister hat Mia?“  
*Mia punya berapa saudara?*

**Giliran pemain.** Kartu bergambar satu saudara laki-laki dan satu perempuan. «Sie hat zwei Geschwister, einen Bruder und eine Schwester.» Lalu tanyakan jumlah anak di foto lain.

**Jika maksud tersampaikan.** Herr Bauer mencari bingkai untuk dua saudara.

**Jika butuh bantuan.** Hitung hanya generasi yang sama. Ulang dengan «Wie viele Kinder …?» dan kartu tiga anak.

### Menyebut status pernikahan dan tinggal bersama · `a1-u3-o4`

**Frau Lehmann, latihan bersama.** Baca status dari kartu tokoh fiktif. verheiratet berarti menikah, ledig lajang, geschieden bercerai; zusammen wohnen menyatakan tinggal bersama.

**Mia** — „Wohnen Eva und Tom zusammen?“  
*Apakah Eva dan Tom tinggal bersama?*

**Giliran pemain.** Kartu menyebut satu alamat dan menikah. «Ja, sie wohnen zusammen. Sie sind verheiratet.» Cocokkan dua kartu lain dengan ledig dan geschieden.

**Jika maksud tersampaikan.** Alamat keluarga membantu mengembalikan amplop yang tepat.

**Jika butuh bantuan.** Jangan simpulkan status dari alamat. Coba dua saudara lajang dengan satu alamat.

**Dialog transisi.**

**Herr Bauer** — „Ach, das ist ja meine Schwester!“  
*Oh, itu ternyata saudara perempuanku!*

## Adegan 3 · Possessiv & besuchen

Pagar taman. Dua kerabat menunggu foto. Dengarkan siapa mengunjungi siapa sebelum menyerahkan amplop.

**Materi tutor yang dapat dibuka:** mein, dein, sein, ihr • Akkusativ setelah besuchen • Kalimat dengan dua keterangan • Berbicara tentang perasaan.  
**Kosakata sumber:** Onkel, Tante, Cousin, Cousine, besuchen. **Latihan asal:** D4.

### Memakai possessiv dein/sein/ihr dan Akkusativ setelah besuchen · `a1-u3-o5`

**Frau Lehmann, latihan bersama.** Tentukan pemilik lebih dulu. Saat besuchen diikuti objek maskulin, mein menjadi meinen, dein menjadi deinen dan sein menjadi seinen.

**Mia** — „Leon besucht heute seinen Onkel. Und wen besuchst du?“  
*Leon mengunjungi pamannya hari ini. Lalu siapa yang kamu kunjungi?*

**Giliran pemain.** «Ich besuche meinen Onkel.» Tanyakan «Besuchst du deinen Onkel?» Pasangkan kartu Mia → ihr Bruder dan Leon → sein Bruder.

**Jika maksud tersampaikan.** Pemilik amplop menjawab dan mengundang kalian ke kafe.

**Jika butuh bantuan.** Jika pemilik tertukar, tunjuk panah dari nama ke kerabat. Coba «Mia besucht ihren Bruder».

**Dialog transisi.**

**Mia** — „Jetzt brauche ich einen Kaffee. Du auch?“  
*Sekarang aku ingin kopi. Kamu juga?*

## Contoh cabang saat maksud belum jelas

**Mia** — „Das ist mein Onkel. Mein Vater steht hier links.“  
*Itu pamanku. Ayahku ada di kiri sini.*

Sorot dua cabang pada bagan. Geser label tanpa mengulang percakapan dari awal.

## Pertemuan mandiri

Dengan kartu keluarga fiktif baru, perkenalkan dua orang, jawab pertanyaan jumlah saudara dan jelaskan siapa mengunjungi pamannya. Serahkan bingkai kepada keluarga yang cocok.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Pemilik foto menulis ucapan terima kasih dan mengundang kalian mencicipi kue di kafe.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u3-o1` | 1, 2 | 1 |
| `a1-u3-o2` | 1 | 1 |
| `a1-u3-o3` | 2 | 2 |
| `a1-u3-o4` | 2 | 2 |
| `a1-u3-o5` | 3 | 3 |

**Bacaan katalog Arena:** *Meine große Familie* (textId 8), *Ein Besuch bei Oma* (textId 9)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 3](../../src/data/lessons/a1_unit3_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
