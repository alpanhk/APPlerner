# Bab 05 · Jaket yang tertukar

**Materi:** Belanja & harga. **Pemeran adegan:** Penjual pakaian, kasir, Mia, Herr Bauer. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Jaket, label ukuran, cermin, struk, kunci.

## Adegan 1 · Farben und Größen

Toko pakaian bekas. Dua jaket biru tergantung berdampingan. Cari jaket untuk giliran pertama di meja informasi.

**Penjual** — „Für das Fest? Dann probieren Sie die Jacke ruhig an.“  
*Untuk acaranya? Silakan coba jaketnya dahulu.*

**Materi tutor yang dapat dibuka:** Kata sifat warna • Menanyakan ukuran • Akkusativ: mencari barang.  
**Kosakata sumber:** Bluse, Mantel, Rock, Sakko, Stiefel, Kleiderbügel, Knopf, Sonderpreis. **Latihan asal:** D2.

### Menyebut warna dan menyelaraskan kata sifat · `a1-u5-o1`

**Frau Lehmann, latihan bersama.** Sesudah ist, warna tetap blau. Sebelum kata benda, dengarkan akhiran pada eine blaue Jacke dan ein rotes Kleid.

**Penjual** — „Hier sind zwei Jacken. Welche Farbe suchen Sie?“  
*Ada dua jaket. Anda mencari warna apa?*

**Giliran pemain.** Kartu biru. «Ich suche eine blaue Jacke. Die Jacke ist blau.» Cocokkan juga ein rotes Kleid dengan gambar.

**Jika maksud tersampaikan.** Penjual meletakkan pilihan warnamu di cermin.

**Jika butuh bantuan.** Jika salah warna, bandingkan kedua label. Ulang dengan hijau pada «ein grünes Hemd».

### Mencari dan meminta barang dengan Akkusativ · `a1-u5-o3`

**Frau Lehmann, latihan bersama.** Sesudah suchen/haben, perhatikan einen Mantel, eine Jacke, ein Hemd dan die Schuhe.

**Penjual** — „Was suchen Sie für das Fest?“  
*Apa yang Anda cari untuk acara itu?*

**Giliran pemain.** Gunakan kartu pakaian. «Ich suche einen Mantel. Haben Sie eine Jacke?» Lanjutkan permintaan untuk ein Hemd dan die Schuhe.

**Jika maksud tersampaikan.** Penjual menaruh barang yang diminta di gantungan.

**Jika butuh bantuan.** Jika artikel benar tetapi jenis barang keliru, tunjuk siluet. Coba dengan einen Pullover.

## Adegan 2 · Im Geschäft

Kamar pas. Penjaga toko memberi dua ukuran. Pilih yang cocok berdasarkan kartu ukuran tokoh dan pengalaman mencoba.

**Materi tutor yang dapat dibuka:** Meminta barang • Mencoba pakaian • Menyatakan cocok.  
**Kosakata sumber:** Kleiderbügel, Knopf, Sonderpreis, Einkaufstasche, Einkaufszentrum, Preisschild, Umkleidekabine, Gutschein. **Latihan asal:** D1.

### Menanyakan ukuran dan menyatakan cocok/tidak · `a1-u5-o2`

**Frau Lehmann, latihan bersama.** Pakai Größe untuk ukuran; zu klein berarti terlalu kecil. Kalimat «Sie passt» menyatakan jaket pas.

**Penjual** — „Welche Größe tragen Sie?“  
*Anda memakai ukuran berapa?*

**Giliran pemain.** Pakai ukuran fiktif M. «Ich trage Größe M.» Pada jaket S jawab «Sie ist zu klein», lalu untuk M «Sie passt.» Tukar peran dan tanyakan ukuran.

**Jika maksud tersampaikan.** Penjual menggantung ukuran yang sesuai di pintu kamar pas.

**Jika butuh bantuan.** Jika label sudah cocok tetapi panjang lengan keliru, coba «zu lang», «zu kurz», lalu bandingkan «zu groß».

### Mencoba pakaian dan menanyakan ruang ganti · `a1-u5-o4`

**Frau Lehmann, latihan bersama.** Kata an pada anprobieren pindah ke akhir kalimat utama. Umkleidekabine adalah kamar pas.

**Mia** — „Möchtest du die Jacke erst anprobieren?“  
*Mau mencoba jaketnya dahulu?*

**Giliran pemain.** Tanya «Wo ist die Umkleidekabine?» Lalu konfirmasi «Ich probiere die Jacke an.»

**Jika maksud tersampaikan.** Penjaga membuka kamar pas sesudah ditanya.

**Jika butuh bantuan.** Jika an hilang, tutor menunjukkan kartu verba kedua. Coba «Ich probiere das Hemd an.»

**Dialog transisi.**

**Kasir** — „Entschuldigung, das ist die falsche Tüte.“  
*Maaf, itu tas belanja yang keliru.*

## Adegan 3 · Bezahlen und umtauschen

Kasir. Setelah membayar, kamu melihat label pada tas belanja milik pelanggan lain. Struk menjadi petunjuk untuk menukar barang.

**Materi tutor yang dapat dibuka:** Menanyakan harga • Membayar di kasir • Menukar barang.  
**Kosakata sumber:** Preisschild, Umkleidekabine, Gutschein, Kassenzettel, Rückgabe, Bluse, Mantel, Rock. **Latihan asal:** D4.

### Menanyakan harga, membayar, dan menukar barang · `a1-u5-o5`

**Frau Lehmann, latihan bersama.** Simpan Quittung untuk penukaran. Bedakan cara bayar bar dari mit Karte.

**Kasir** — „Das macht zwölf Euro. Wie möchten Sie bezahlen?“  
*Totalnya dua belas euro. Bagaimana Anda ingin membayar?*

**Giliran pemain.** Tanya «Was kostet die Jacke?» Bayar «Ich zahle bar.» Minta «Eine Quittung, bitte.» Setelah tas tertukar «Ich möchte die Jacke umtauschen.»

**Jika maksud tersampaikan.** Kasir mencocokkan struk dan memberi tas yang benar.

**Jika butuh bantuan.** Jika meminta harga lagi saat menukar, sorot struk. Coba pembelian kedua dengan kartu.

**Dialog transisi.**

**Herr Bauer** — „Hier ist der Schlüssel. Morgen machen wir den Raum auf.“  
*Ini kuncinya. Besok kita buka ruangannya.*

## Contoh cabang saat maksud belum jelas

**Penjual** — „Die Ärmel sind zu kurz. Möchten Sie eine andere Größe probieren?“  
*Lengannya terlalu pendek. Mau mencoba ukuran lain?*

Biarkan pemain meminta ukuran berikut. Uang belum berpindah.

## Pertemuan mandiri

Dari kartu pesanan baru, cari pakaian dengan warna dan ukuran tepat, coba, bayar, lalu tukarkan satu barang memakai struk.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Jaket yang tepat punya kantong lebar untuk menyimpan kunci ruang pertemuan dari Herr Bauer.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u5-o1` | 1 | 1 |
| `a1-u5-o2` | 1, 2 | 2 |
| `a1-u5-o3` | 1, 2 | 1 |
| `a1-u5-o4` | 2 | 2 |
| `a1-u5-o5` | 3 | 3 |

**Bacaan katalog Arena:** *Im Kleidungsgeschäft* (textId 12), *Ein Geschenk für Tom* (textId 13)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 5](../../src/data/lessons/a1_unit5_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
