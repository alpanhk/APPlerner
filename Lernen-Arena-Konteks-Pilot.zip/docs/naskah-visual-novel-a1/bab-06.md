# Bab 06 · Kunci ruang bersama

**Materi:** Rumah & tempat tinggal. **Pemeran adegan:** Herr Bauer, Mia. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Denah sebelum/sesudah, lampu, kursi, daftar piket.

## Adegan 1 · Zimmer und Möbel

Ruang warga baru dibuka setelah lama terkunci. Ada denah lama, tetapi sebagian perabot telah dipindah.

**Herr Bauer** — „Vorsicht, hinter der Tür steht ein Stuhl.“  
*Hati-hati, ada kursi di belakang pintu.*

**Materi tutor yang dapat dibuka:** Benda di rumah • Es gibt + Akkusativ • Mendeskripsikan kamar.  
**Kosakata sumber:** Gardine, Wäschetrockner, Steckdose, Dachboden, Keller, Heizkörper, Möbelstück, Spülmaschine. **Latihan asal:** D1.

### Menyebut bagian rumah dan perabot dengan artikel · `a1-u6-o1`

**Frau Lehmann, latihan bersama.** Beri nama ruangan dan perabot beserta artikelnya. Bandingkan der Stuhl dan die Stühle.

**Herr Bauer** — „Was steht im Wohnzimmer?“  
*Apa yang ada di ruang duduk?*

**Giliran pemain.** Beri label das Wohnzimmer, die Küche, der Tisch, der Stuhl, das Sofa. Sebut bentuk plural die Tische, die Stühle, die Sofas.

**Jika maksud tersampaikan.** Herr Bauer bisa mencocokkan denah dan isi ruangan.

**Jika butuh bantuan.** Jika tertukar ruangan dengan perabot, pilih pintu lalu benda. Ulang dengan das Bett → die Betten.

### Menyatakan keberadaan dengan es gibt + Akkusativ · `a1-u6-o2`

**Frau Lehmann, latihan bersama.** Es gibt diikuti Akkusativ. Gunakan einen Tisch, eine Lampe, ein Sofa atau zwei Stühle.

**Mia** — „Gibt es hier genug Möbel für unsere Gäste?“  
*Apakah ada cukup perabot untuk tamu kita?*

**Giliran pemain.** Dari gambar jawab «Es gibt einen Tisch, eine Lampe, ein Sofa und zwei Stühle.»

**Jika maksud tersampaikan.** Mia mencoret barang yang sudah tersedia dari daftar pinjaman.

**Jika butuh bantuan.** Jika jumlah keliru, hitung pada denah. Coba sudut kedua dengan einen Schrank.

## Adegan 2 · Wo steht was?

Sudut baca. Mia memegang lampu di depan dua meja. Bedakan melaporkan letaknya dan meminta seseorang memindahkannya.

**Materi tutor yang dapat dibuka:** Wo? — letak benda • Posisi sein dan stehen • Tempat dan arah.  
**Kosakata sumber:** Heizkörper, Möbelstück, Spülmaschine, Türschloss, Türmatte, Bücherregal, Sessel, Matratze. **Latihan asal:** D6.

### Menjelaskan letak dengan Wo? dan preposisi Dativ · `a1-u6-o3`

**Frau Lehmann, latihan bersama.** Wo menanyakan posisi yang sudah tetap. Buku biasa liegen, lampu yang berdiri biasa stehen.

**Mia** — „Wo liegt das Buch? Und wo steht die Lampe?“  
*Di mana bukunya terletak? Di mana lampunya berdiri?*

**Giliran pemain.** Dari gambar «Das Buch liegt auf dem Tisch. Die Lampe steht im Wohnzimmer.» Tambah lokasi kedua «in der Küche».

**Jika maksud tersampaikan.** Mia menemukan buku tamu dan menaruh pembatas pada halaman terakhir.

**Jika butuh bantuan.** Jika memakai auf den Tisch untuk lokasi, tunjuk benda diam. Ulang dengan kunci di atas kursi.

### Membedakan Wo? dan Wohin? · `a1-u6-o4`

**Frau Lehmann, latihan bersama.** Wohin memakai arah tujuan. «Ich stelle den Stuhl ins Zimmer.» Sesudah sampai, «Der Stuhl steht im Zimmer.»

**Herr Bauer** — „Wohin stellen wir den Tisch?“  
*Ke mana kita menempatkan meja ini?*

**Giliran pemain.** Kartu panah menuju dapur. «Wir stellen den Tisch in die Küche.» Laporkan setelah selesai «Er steht in der Küche.» Coba arah ke ruang duduk dengan ins.

**Jika maksud tersampaikan.** Gambar denah berganti ke susunan baru setelah jawaban arah.

**Jika butuh bantuan.** Jika menjawab lokasi awal, sorot ujung panah. Ulang dengan memindahkan kursi ke kamar.

**Dialog transisi.**

**Mia** — „Hier am Fenster können wir später lesen.“  
*Nanti kita bisa membaca di dekat jendela ini.*

## Adegan 3 · Arbeit im Haushalt

Daftar piket di pintu. Pilih satu tugas, bagi sisanya dengan Mia, lalu tulis ruangan yang sudah siap.

**Materi tutor yang dapat dibuka:** Verba pisah aufräumen • Tugas rumah • Müssen untuk kewajiban.  
**Kosakata sumber:** Bücherregal, Sessel, Matratze, Fußboden, Rollladen, Gardine, Wäschetrockner, Steckdose. **Latihan asal:** D3.

### Membicarakan pekerjaan rumah dengan aufräumen dan müssen · `a1-u6-o5`

**Frau Lehmann, latihan bersama.** Pada aufräumen, awalan muncul di akhir. Dengan müssen, infinitif tetap utuh di akhir.

**Mia** — „Ich räume das Zimmer auf. Was musst du noch machen?“  
*Aku merapikan kamar. Apa lagi yang harus kamu kerjakan?*

**Giliran pemain.** Pilih tugas pada kartu «Ich muss die Fenster putzen. Ich muss die Handtücher waschen.» Sebutkan tugas yang diambil dengan «Ich räume die Küche auf.»

**Jika maksud tersampaikan.** Mia menandai pembagian tugas dan membuka papan peta.

**Jika butuh bantuan.** Jika verba kedua terpotong, tutor memperlihatkan dua slot. Ulang «Wir müssen das Zimmer aufräumen.»

**Dialog transisi.**

**Mia** — „Eine Karte! Aber wo ist die Post?“  
*Ada peta! Tapi di mana kantor posnya?*

## Contoh cabang saat maksud belum jelas

**Mia** — „Da steht er schon. Wohin soll ich ihn stellen?“  
*Di sana kursinya memang sudah ada. Harus kuletakkan di mana?*

Bedakan titik sekarang dan tujuan pada denah. Putar kembali ujaran tentang arah.

## Pertemuan mandiri

Amati denah kedua. Laporkan satu benda dan letaknya, beri instruksi memindahkannya, lalu sepakati tugas yang tersisa.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Di bawah kursi muncul peta kota tanpa keterangan. Kalian perlu menunjukkan jalan kepada tamu pertama.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u6-o1` | 1 | 1 |
| `a1-u6-o2` | 1 | 1 |
| `a1-u6-o3` | 2 | 2 |
| `a1-u6-o4` | 2 | 2 |
| `a1-u6-o5` | 3 | 3 |

**Bacaan katalog Arena:** *Unsere neue Wohnung* (textId 14), *Ein ruhiger Abend zu Hause* (textId 15)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 6](../../src/data/lessons/a1_unit6_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
