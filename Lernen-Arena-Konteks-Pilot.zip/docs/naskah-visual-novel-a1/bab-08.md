# Bab 08 · Giliran pertama

**Materi:** Pekerjaan & kegiatan harian. **Pemeran adegan:** Rekan panitia, Mia. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Map lamaran, papan giliran, pesan Mia.

## Adegan 1 · Ein Arbeitstag

Meja informasi. Ada tiga kartu tugas dan telepon mulai berdering. Susun urutan membuka meja agar tamu pertama bisa dilayani.

**Rekan** — „Schön, dass du da bist. In zehn Minuten öffnen wir.“  
*Senang kamu sudah datang. Sepuluh menit lagi kita buka.*

**Materi tutor yang dapat dibuka:** Urutan kegiatan • Kata kerja pisah anfangen • Tempat kerja.  
**Kosakata sumber:** Dienstplan, Dienstreise, Bürogebäude, Lohnabrechnung, Teamleiterin, Empfang, Kantine, Aktenordner. **Latihan asal:** D3.

### Menceritakan urutan rutinitas kerja · `a1-u8-o1`

**Frau Lehmann, latihan bersama.** Setelah erst, dann, danach, letakkan verba terkonjugasi pada posisi kedua.

**Rekan** — „Was machen wir zuerst am Infotisch?“  
*Apa yang kita lakukan dahulu di meja informasi?*

**Giliran pemain.** Urutkan tiga kartu «Erst öffne ich die Tür. Dann lese ich die Liste. Danach begrüße ich die Gäste.»

**Jika maksud tersampaikan.** Rekan membalik papan menjadi «Geöffnet».

**Jika butuh bantuan.** Jika subjek mendahului verba sesudah dann, tutor memindahkan kartu verba. Ulang dengan tiga tugas penutupan.

### Memakai anfangen sebagai verba pisah · `a1-u8-o2`

**Frau Lehmann, latihan bersama.** anfangen terpisah. ich fange an, du fängst an, er fängt an.

**Rekan** — „Wann fängst du an? Und wann fängt Leon an?“  
*Kapan kamu mulai? Kapan Leon mulai?*

**Giliran pemain.** Jadwal menunjukkan 8 dan 9. «Ich fange um acht Uhr an. Leon fängt um neun Uhr an.» Lalu tanyakan giliran rekan.

**Jika maksud tersampaikan.** Dua penanda jam muncul pada papan giliran.

**Jika butuh bantuan.** Jika an hilang atau jam tertukar, sorot dua nama. Ulang dengan wir fangen … an.

### Menyebut tempat kerja dan departemen · `a1-u8-o3`

**Frau Lehmann, latihan bersama.** Pilih am Arbeitsplatz untuk tempat kerja, am Schreibtisch untuk meja kerja, in der Abteilung untuk bagian kantor.

**Rekan** — „Wo ist Mia? Und wo arbeitest du?“  
*Di mana Mia? Dan kamu bekerja di mana?*

**Giliran pemain.** Foto menunjukkan Mia di meja, pemain di bagian informasi. «Mia ist am Schreibtisch. Ich arbeite in der Abteilung für Information.» Pasang label «am Arbeitsplatz» pada foto umum.

**Jika maksud tersampaikan.** Map dialamatkan ke bagian yang sesuai.

**Jika butuh bantuan.** Jika ruangan dan meja tertukar, pilih gambar jarak dekat. Ulang dengan rekan lain dan «am Schreibtisch».

## Adegan 2 · Aufgaben und Kollegen

Kantor belakang. Map lamaran relawan terselip di antara berkas rapat. Jelaskan kepada rekan apa yang harus dikerjakan bersama.

**Materi tutor yang dapat dibuka:** Tugas sehari-hari • Membuat kalimat dengan mit • Bewerbung dan Lebenslauf.  
**Kosakata sumber:** Empfang, Kantine, Aktenordner, Schulungsraum, Pausenbrot, Frühschicht, Pausenraum, Arbeitsweg. **Latihan asal:** D2.

### Membicarakan tugas dan rekan kerja · `a1-u8-o4`

**Frau Lehmann, latihan bersama.** Susun berkas Bewerbung dengan Lebenslauf. Untuk rekan setelah mit gunakan Dativ.

**Rekan** — „Was erledigst du heute mit deiner Kollegin?“  
*Tugas apa yang hari ini kamu selesaikan bersama rekanmu?*

**Giliran pemain.** Susun label Bewerbung, Lebenslauf, Besprechung. «Ich erledige die Aufgabe mit meiner Kollegin. Wir lesen den Lebenslauf.»

**Jika maksud tersampaikan.** Map lamaran tiba di rapat yang tepat.

**Jika butuh bantuan.** Jika map ditempatkan di berkas jadwal, lihat judulnya. Ulang «Ich habe eine Besprechung mit meinem Kollegen.»

**Dialog transisi.**

**Rekan** — „Danke, jetzt ist die Liste vollständig.“  
*Terima kasih, daftarnya sekarang lengkap.*

## Adegan 3 · Arbeitszeit und Pflichten

Papan giliran. Satu rekan datang terlambat. Sepakati jam kerja, waktu istirahat, dan tugas yang sanggup kamu ambil.

**Materi tutor yang dapat dibuka:** Müssen — kewajiban • Können — kemampuan • Jam kerja von … bis.  
**Kosakata sumber:** Frühschicht, Pausenraum, Arbeitsweg, Telefonzentrale, Mittagspause, Dienstplan, Dienstreise, Bürogebäude. **Latihan asal:** D10.

### Menyatakan kewajiban, kemampuan, dan jam kerja · `a1-u8-o5`

**Frau Lehmann, latihan bersama.** müssen untuk kewajiban, können untuk kemampuan. Akhiri dengan infinitif dan sebut batas jam memakai von … bis.

**Rekan** — „Ich komme erst um zehn. Wann kannst du am Infotisch arbeiten?“  
*Aku baru datang pukul sepuluh. Kapan kamu bisa bekerja di meja informasi?*

**Giliran pemain.** Kartu tugas 8–10, jeda 10–10.15. «Ich kann von acht bis zehn Uhr arbeiten. Ich muss die Tür öffnen. Von zehn bis Viertel nach zehn habe ich Pause.»

**Jika maksud tersampaikan.** Rekan mengisi celah giliran di papan.

**Jika butuh bantuan.** Jika tugas dan kemampuan tertukar, tandai tugas wajib. Ulang dengan jadwal sore dan jeda baru.

**Dialog transisi.**

**Mia, pesan tertulis** — „Mein Hals tut weh. Kommst du morgen mit?“  
*Tenggorokanku sakit. Besok kamu mau menemaniku?*

## Contoh cabang saat maksud belum jelas

**Rekan** — „Um zehn beginnt meine Schicht. Wer ist vorher hier?“  
*Giliranku mulai pukul sepuluh. Siapa yang ada di sini sebelumnya?*

Sorot celah jadwal. Pemain dapat memperbaiki jam saja.

## Pertemuan mandiri

Baca jadwal pengganti, jelaskan giliran orang ketiga, urutan kerja, rekan serta jeda. Tempel jadwal yang dapat dijalankan.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Saat menutup meja, Mia meninggalkan pesan bahwa tenggorokannya sakit. Ia meminta ditemani membuat janji.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u8-o1` | 1 | 1 |
| `a1-u8-o2` | 1 | 1 |
| `a1-u8-o3` | 1 | 1 |
| `a1-u8-o4` | 2 | 2 |
| `a1-u8-o5` | 3 | 3 |

**Bacaan katalog Arena:** *Mein erster Arbeitstag* (textId 18)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 8](../../src/data/lessons/a1_unit8_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
