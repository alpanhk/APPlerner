# Bab 09 · Suara Mia serak

**Materi:** Kesehatan & tubuh. **Pemeran adegan:** Mia, petugas praktik, apoteker. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Kalender, kartu asuransi fiktif, resep dan surat ilustratif.

## Adegan 1 · Körper und Beschwerden

Dapur pagi. Mia menulis keluhannya di secarik kertas. Bantu ia menyampaikan keluhan tokoh fiktif kepada petugas praktik.

**Mia** — „Heute spreche ich lieber wenig. Hilfst du mir?“  
*Hari ini aku ingin sedikit bicara. Kamu mau membantuku?*

**Materi tutor yang dapat dibuka:** Keluhan dengan haben • Bertanya tentang kondisi • Sejak kapan?.  
**Kosakata sumber:** Nasenspray, Bauchschmerz, Grippe, Halsschmerz, Kopfschmerz, Versicherungskarte, Tropfen, Augentropfen. **Latihan asal:** D1.

### Menyebut keluhan kesehatan dengan haben · `a1-u9-o1`

**Frau Lehmann, latihan bersama.** Untuk menyatakan keluhan, gunakan haben dengan nama keluhannya. Bandingkan Husten, Fieber, Kopfschmerzen, Halsschmerzen.

**Mia** — „Mein Hals tut weh. Was schreibe ich auf die Karte?“  
*Tenggorokanku sakit. Apa yang kutulis di kartu?*

**Giliran pemain.** Berperan sebagai Mia pada kartu latihan «Ich habe Halsschmerzen.» Cocokkan tiga kartu lain dengan Husten, Fieber dan Kopfschmerzen.

**Jika maksud tersampaikan.** Petugas membaca keluhan yang sesuai dengan kartu.

**Jika butuh bantuan.** Jika memilih dua keluhan yang tidak disebut, putar ulang. Coba laporkan keluhan tokoh lain dalam orang ketiga.

### Menanyakan kondisi dan durasi dengan seit · `a1-u9-o2`

**Frau Lehmann, latihan bersama.** Was fehlt Ihnen? untuk bertanya sopan. seit gestern atau seit zwei Tagen menyatakan durasi hingga sekarang.

**Petugas** — „Guten Morgen. Wie geht es Ihnen? Seit wann haben Sie Beschwerden?“  
*Selamat pagi. Bagaimana kondisi Anda? Sejak kapan mengalami keluhan?*

**Giliran pemain.** Kartu bertanda kemarin. «Ich habe seit gestern Halsschmerzen.» Tukar peran dan tanya «Was fehlt Ihnen?»

**Jika maksud tersampaikan.** Petugas menuliskan durasi yang disebutkan.

**Jika butuh bantuan.** Jika memakai waktu janji sebagai durasi, tandai awal keluhan. Ulang dengan kartu «seit zwei Tagen».

## Adegan 2 · Beim Arzt

Meja penerima pasien. Dua slot kosong terlihat di kalender. Mia baru bisa datang sesudah tengah hari. Setelah memilih, petugas meminta kartu asuransi.

**Materi tutor yang dapat dibuka:** Membuat janji • Di ruang praktik • Menjelaskan gejala.  
**Kosakata sumber:** Versicherungskarte, Tropfen, Augentropfen, Schmerzmittel, Apotheker, Sprechstunde, Untersuchung, Arzttermin. **Latihan asal:** D5.

### Membuat janji dokter · `a1-u9-o3`

**Frau Lehmann, latihan bersama.** Untuk meminta janji katakan «Haben Sie einen Termin frei?» Bedakan am Vormittag dan am Nachmittag.

**Petugas** — „Die Sprechstunde ist um zehn und um fünfzehn Uhr. Wann können Sie kommen?“  
*Jam praktik tersedia pukul sepuluh dan lima belas. Kapan Anda bisa datang?*

**Giliran pemain.** Mia luang setelah tengah hari. «Ich möchte einen Arzttermin. Haben Sie am Nachmittag einen Termin frei?» Konfirmasi pukul tiga sore.

**Jika maksud tersampaikan.** Petugas memberikan kartu janji dengan waktu yang dipilih.

**Jika butuh bantuan.** Jika memilih pagi, tunjuk kalender Mia dan tawarkan pilihan lagi. Coba jadwal tokoh lain yang hanya luang pagi.

### Menjelaskan gejala dan pemeriksaan · `a1-u9-o4`

**Frau Lehmann, latihan bersama.** Jelaskan gejala dengan «Mein Hals tut weh» atau «Ich fühle mich müde». Di praktik ada Versicherungskarte dan Untersuchung.

**Petugas** — „Haben Sie Ihre Versicherungskarte für die Untersuchung dabei?“  
*Apakah Anda membawa kartu asuransi untuk pemeriksaan?*

**Giliran pemain.** Pilih kartu asuransi dari tiga benda. Sampaikan dari kartu peran «Mein Hals tut weh. Ich fühle mich müde.»

**Jika maksud tersampaikan.** Petugas mengembalikan kartu dan mempersilakan tokoh ke ruang periksa.

**Jika butuh bantuan.** Jika memilih kartu bank, tunjuk tulisan Versicherung. Ulang dengan menanyakan letak ruang pemeriksaan.

**Dialog transisi.**

**Petugas** — „Der Termin am Nachmittag ist noch frei.“  
*Janji pada sore hari masih tersedia.*

## Adegan 3 · In der Apotheke

Apotek. Mia menyerahkan resep dari cerita. Dengarkan instruksi administratif pada kartu dan ulangi isinya. Adegan ini melatih bahasa.

**Materi tutor yang dapat dibuka:** Obat dan resep • Sollen untuk saran • Perban dan izin sakit.  
**Kosakata sumber:** Sprechstunde, Untersuchung, Arzttermin, Sprechzimmer, Wundsalbe, Nasenspray, Bauchschmerz, Grippe. **Latihan asal:** D10.

### Memahami saran obat dengan sollen · `a1-u9-o5`

**Frau Lehmann, latihan bersama.** Sesudah sollen, taruh infinitif di akhir. Dengarkan siapa yang menyampaikan pesan dan dokumen mana yang disebut.

**Apoteker** — „Sie sollen das Rezept mitbringen. Die Krankmeldung bekommen Sie in der Praxis.“  
*Anda diminta membawa resep. Surat keterangan sakit bisa didapat di tempat praktik.*

**Giliran pemain.** Laporkan kembali «Ich soll das Rezept mitbringen.» Cocokkan Apotheker, Schmerzmittel, Rezept dan Krankmeldung. Pada kartu instruksi bahasa «Sie sollen die Tablette mit Wasser nehmen», pilih gambar yang cocok.

**Jika maksud tersampaikan.** Mia menyimpan resep dan surat pada kantong berbeda.

**Jika butuh bantuan.** Jika dokumen tertukar, cocokkan nama dengan penerbit. Ulang dengan kartu baru «Ich soll den Apotheker fragen.»

**Dialog transisi.**

**Mia, beberapa hari kemudian** — „Mir geht es besser. Hast du Lust auf Musik?“  
*Aku sudah lebih baik. Kamu mau bermain musik?*

## Contoh cabang saat maksud belum jelas

**Petugas praktik** — „Zehn Uhr ist am Vormittag. Passt der Nachmittag besser?“  
*Pukul sepuluh itu pagi. Apakah sore lebih cocok?*

Tampilkan dua slot kembali dan biarkan pemain memilih sesuai kartu.

## Pertemuan mandiri

Dengan kartu pasien fiktif lain, tanyakan sejak kapan keluhannya, minta janji yang cocok, dan sampaikan kembali pesan pada kertas praktik.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Mia beristirahat. Beberapa hari kemudian ia mengirim foto raket dan bertanya apakah kamu mau ikut kegiatan klub.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u9-o1` | 1 | 1 |
| `a1-u9-o2` | 1 | 1 |
| `a1-u9-o3` | 2 | 2 |
| `a1-u9-o4` | 2 | 2 |
| `a1-u9-o5` | 3 | 3 |

**Bacaan katalog Arena:** *Ein Termin beim Arzt* (textId 19)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 9](../../src/data/lessons/a1_unit9_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
