# Bab 11 · Peron berubah

**Materi:** Transportasi & perjalanan. **Pemeran adegan:** Mia, petugas stasiun, pengumuman. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Tiket, koper, dua versi papan peron.

## Adegan 1 · Eine Reise planen

Meja dengan tiket dan peta. Mia menandai Leipzig, lalu menunjukkan kartu pos dari Swiss. Siapkan perjalanan yang cocok dengan undangan.

**Mia** — „Die Tickets habe ich. Hast du das Buch?“  
*Tiketnya sudah kubawa. Bukunya ada padamu?*

**Materi tutor yang dapat dibuka:** Tujuan dengan nach • Jadwal perjalanan • Barang bawaan.  
**Kosakata sumber:** Bahnsteig, Reisepass, Reisetasche, Kofferanhänger, Abfahrtsanzeige, Umstieg, Direktzug, Sitzplatzkarte. **Latihan asal:** D9.

### Menyebut tujuan perjalanan dengan nach dan in + negara · `a1-u11-o1`

**Frau Lehmann, latihan bersama.** Untuk kota dan negara tanpa artikel gunakan nach. Untuk tujuan negara berartikel seperti Swiss gunakan in die Schweiz.

**Mia** — „Wohin fahren wir heute? Und wohin fährt Herr Bauer im Sommer?“  
*Hari ini kita pergi ke mana? Musim panas nanti Herr Bauer pergi ke mana?*

**Giliran pemain.** Tiket pemain Leipzig, kartu liburan Herr Bauer Swiss. «Wir fahren nach Leipzig. Herr Bauer fährt in die Schweiz.» Bandingkan «nach Deutschland».

**Jika maksud tersampaikan.** Mia menyimpan tiket Leipzig di sampul buku.

**Jika butuh bantuan.** Jika semua memakai nach, buka label die Schweiz. Ulang dengan Berlin dan Swiss pada kartu terbalik.

### Menyebut jadwal keberangkatan dan kedatangan · `a1-u11-o2`

**Frau Lehmann, latihan bersama.** Abfahrt ialah keberangkatan, Ankunft ialah kedatangan. Pada «Wann kommt der Zug an?» bagian an terdengar paling akhir.

**Mia** — „Wann fährt unser Zug ab? Wann kommt er an?“  
*Kapan kereta kita berangkat? Kapan tiba?*

**Giliran pemain.** Tiket 09.10–10.25. «Er fährt um neun Uhr zehn ab. Er kommt um zehn Uhr fünfundzwanzig an.» Tanyakan waktu tiba kereta kedua.

**Jika maksud tersampaikan.** Mia memberi tahu tuan rumah kapan menjemput.

**Jika butuh bantuan.** Jika menyebut keberangkatan dua kali, tandai kota awal dan akhir. Ulang dengan tiket berbeda.

### Membawa barang bawaan dengan mitnehmen · `a1-u11-o3`

**Frau Lehmann, latihan bersama.** mitnehmen terpisah menjadi nehme … mit. Kenali der Koffer, der Rucksack, der Reisepass.

**Mia** — „Was nimmst du auf die Reise mit?“  
*Apa yang kamu bawa dalam perjalanan?*

**Giliran pemain.** Kartu daftar sesuai cerita. «Ich nehme den Rucksack und den Reisepass mit.» Kenali koper yang ditinggal pada kartu ini.

**Jika maksud tersampaikan.** Barang yang dipilih muncul di dekat tiket.

**Jika butuh bantuan.** Jika menaruh mit di tengah, tutor memberi contoh dengan satu benda. Ulang pada «Wir nehmen den Koffer mit.»

## Adegan 2 · Am Bahnhof

Stasiun. Bunyi pengumuman sekali. Papan keberangkatan berganti saat kalian tiba. Kereta terlambat dan jadwal sambungan harus diperiksa.

**Materi tutor yang dapat dibuka:** Menanyakan peron • Keterlambatan • Tiket dan tempat duduk.  
**Kosakata sumber:** Umstieg, Direktzug, Sitzplatzkarte, Fahrkartenkontrolle, Fensterplatz, Anzeigetafel, Ticketschalter, Reiseplan. **Latihan asal:** D6.

### Menanyakan peron, keterlambatan, dan sambungan · `a1-u11-o4`

**Frau Lehmann, latihan bersama.** Auf welchem Gleis meminta peron/jalur. Verspätung berarti terlambat; Anschluss adalah sambungan berikutnya.

**Petugas** — „Der Zug hat zehn Minuten Verspätung. Er fährt heute von Gleis vier ab.“  
*Kereta terlambat sepuluh menit. Hari ini kereta berangkat dari jalur empat.*

**Giliran pemain.** Tanyakan «Auf welchem Gleis fährt der Zug ab?» Pilih jalur 4 sesuai pengumuman terbaru, lalu tanyakan «Erreiche ich meinen Anschluss?»

**Jika maksud tersampaikan.** Pemain tiba di jalur terbaru. Petugas membuka jadwal sambungan.

**Jika butuh bantuan.** Jika memilih angka lama, bandingkan tiket dengan papan baru. Ulang saat peron berubah dari 2 ke 5.

**Dialog transisi.**

**Pengumuman** — „Achtung, der Zug fährt heute von Gleis vier ab.“  
*Perhatian, hari ini kereta berangkat dari jalur empat.*

## Adegan 3 · Informationen und Reservierung

Loket informasi. Ada tiket namun tempat duduk belum dipesan. Cari sambungan dan pesan kursi agar buku tamu ikut dengan aman.

**Materi tutor yang dapat dibuka:** Meminta informasi • Di biro perjalanan • Memastikan rencana.  
**Kosakata sumber:** Anzeigetafel, Ticketschalter, Reiseplan, Reisezeit, Gepäckstück, Bahnsteig, Reisepass, Reisetasche. **Latihan asal:** D5.

### Memesan tiket/tempat duduk dan meminta informasi · `a1-u11-o5`

**Frau Lehmann, latihan bersama.** Pesan tempat duduk dengan reservieren. Di loket minta informasi dan sambungan, di mesin pilih tiket.

**Petugas** — „Sie möchten nach Leipzig. Brauchen Sie auch einen Sitzplatz?“  
*Anda ingin ke Leipzig. Apakah juga memerlukan tempat duduk?*

**Giliran pemain.** «Ja, ich möchte einen Sitzplatz reservieren. Können Sie mir eine Auskunft geben? Welche Verbindung gibt es?» Cocokkan Fahrkartenautomat dan Ticketschalter dengan layanan pada gambar.

**Jika maksud tersampaikan.** Tiket dan reservasi tampil sebagai dua bukti berbeda.

**Jika butuh bantuan.** Jika hanya membeli tiket, petugas bertanya lagi tentang kursi. Coba reservasi untuk waktu pulang yang berbeda.

**Konfirmasi sebelum berangkat:** „Also, ein Sitzplatz nach Leipzig. Wann kommen wir an?“ (*Jadi, satu tempat duduk ke Leipzig. Kita tiba jam berapa?*) Pemain membacakan jam pada tiket terakhir. Loket memastikan tujuan dan reservasi sebelum tiket dimasukkan ke buku.

**Dialog transisi.**

**Mia** — „Schreib Eva bitte, wann wir wieder zu Hause sind.“  
*Tolong kabari Eva kapan kita kembali ke rumah.*

## Contoh cabang saat maksud belum jelas

**Petugas stasiun** — „Das war das alte Gleis. Hören Sie bitte noch einmal zu.“  
*Itu jalur yang lama. Silakan dengarkan sekali lagi.*

Sediakan teks pengumuman dan putar ulang. Uji berikut memakai perubahan peron lain.

## Pertemuan mandiri

Gunakan tiket kedua. Tentukan tujuan, barang bawaan, jam tiba dan peron terbaru, lalu tanyakan sambungan dan pesan kursi.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Dari kota tujuan, kirim pesan agar tamu tahu jam pertemuan terakhir di ruang warga.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u11-o1` | 1 | 1 |
| `a1-u11-o2` | 1 | 1 |
| `a1-u11-o3` | 1 | 1 |
| `a1-u11-o4` | 2 | 2 |
| `a1-u11-o5` | 2, 3 | 3 |

**Bacaan katalog Arena:** belum ada bacaan bertag unit ini pada katalog A1 yang diperiksa. Gunakan naskah bab dan materi unit sebagai aktivitas inti.

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 11](../../src/data/lessons/a1_unit11_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
