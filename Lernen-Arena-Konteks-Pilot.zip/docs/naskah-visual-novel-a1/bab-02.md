# Bab 02 · Jam yang terlipat

**Materi:** Angka, waktu, harga. **Pemeran adegan:** Mia, penjual pasar. Frau Lehmann hadir melalui percakapan tutor atau jurnal.  
**Aset untuk disiapkan atau dicocokkan dengan stok:** Dua peti, jam, kalender, kuitansi.

## Adegan 1 · Zahlen & Preise

Kios pasar. Ujung daftar Mia basah. Angka 17 dan 70 masih terbaca, tetapi masing-masing milik barang yang berbeda. Dengarkan penjual sebelum menyerahkan uang mainan.

**Penjual** — „Siebzehn oder siebzig? Das macht einen Unterschied!“  
*Tujuh belas atau tujuh puluh? Itu berbeda sekali!*

**Materi tutor yang dapat dibuka:** Angka 1–12 • 13–19: akhiran -zehn • Puluhan & satuan • Harga: Wie viel kostet …?.  
**Kosakata sumber:** Zahl, Preis, Euro, teuer, billig. **Latihan asal:** D1.

### Menyebut angka 1–100 · `a1-u2-o1`

**Frau Lehmann, latihan bersama.** Untuk 21, satuan terdengar dahulu, lalu und dan puluhan. Bedakan siebzehn dan siebzig dengan mendengarkan ujung kata.

**Penjual** — „Die kleine Kiste kostet siebzehn Euro, die große siebzig. Welche nimmst du?“  
*Peti kecil tujuh belas euro, yang besar tujuh puluh. Mau yang mana?*

**Giliran pemain.** Dengan anggaran 20, pilih peti kecil dan ucapkan «Siebzehn Euro». Cocokkan kartu suara 8, 12, 16, 30, 99, 100 dengan angka.

**Jika maksud tersampaikan.** Penjual menaruh peti sesuai angka yang didengar pemain.

**Jika butuh bantuan.** Dengarkan kembali akhiran -zehn atau -zig. Transfer ke kartu umur 18 dan harga 80.

### Menanyakan dan menjawab harga · `a1-u2-o2`

**Frau Lehmann, latihan bersama.** Tanyakan «Wie viel kostet …?» untuk satu barang. teuer dan billig membandingkan harga terhadap anggaran.

**Mia** — „Wir haben nur zehn Euro. Frag mal nach dem Preis!“  
*Kita hanya punya sepuluh euro. Coba tanyakan harganya!*

**Giliran pemain.** «Wie viel kostet der Korb?» Penjual menjawab «Acht Euro.» Bandingkan keranjang kedua berharga 18 dan pilih yang terjangkau.

**Jika maksud tersampaikan.** Keranjang delapan euro masuk daftar. Untuk yang kedua pemain boleh berkata «Das ist zu teuer.»

**Jika butuh bantuan.** Sorot harga dan anggaran. Ulang dengan tas 9 dan 19 euro, jelaskan mana yang lebih murah.

## Adegan 2 · Uhrzeit & Wochentage

Jam di atas kios mati. Penjual menunjuk jadwal tertulis. Tentukan kapan harus kembali mengambil pesanan.

**Materi tutor yang dapat dibuka:** Jam penuh • halb & viertel • Nama hari • Menanyakan jadwal.  
**Kosakata sumber:** Uhr, Stunde, Minute, Montag, Wochenende. **Latihan asal:** D2.

### Menanyakan dan menyebut jam · `a1-u2-o3`

**Frau Lehmann, latihan bersama.** halb neun berarti setengah jalan ke pukul sembilan. viertel nach lewat 15 menit, viertel vor kurang 15 menit.

**Penjual** — „Komm bitte um halb neun wieder.“  
*Tolong kembali pukul setengah sembilan.*

**Giliran pemain.** Atur jam 08.30. Baca kartu berikutnya «acht Uhr», «Viertel nach acht», «Viertel vor neun» dan cocokkan 08.00, 08.15, 08.45.

**Jika maksud tersampaikan.** Penjual menggantung pesanan pada jam yang dipilih.

**Jika butuh bantuan.** Jika 09.30, tunjukkan ruas dari 08.00 ke 09.00. Coba soal baru «halb zehn».

### Menyebut hari dan menanyakan jadwal · `a1-u2-o4`

**Frau Lehmann, latihan bersama.** Nama hari memakai der sebagai kata benda. am menghubungkan hari dengan suatu kegiatan.

**Mia** — „Heute ist Donnerstag. Wann holen wir den Korb ab?“  
*Hari ini Kamis. Kapan kita mengambil keranjang?*

**Giliran pemain.** Susun Montag sampai Sonntag. Catatan «dua hari lagi». Jawab «Am Samstag.» Lalu tanyakan «Wann öffnet der Markt?»

**Jika maksud tersampaikan.** Mia melingkari Sabtu pada kalender.

**Jika butuh bantuan.** Jika tertukar, mulai dari der Donnerstag dan hitung dua kotak. Coba janji sehari setelah Minggu.

**Dialog transisi.**

**Mia** — „Gut, dann trage ich Samstag ein.“  
*Baik, kalau begitu kutulis hari Sabtu.*

## Adegan 3 · Zeitausdrücke: um, am, im

Kalender di jendela. Mia akan menjaga kios sendirian jika catatan untuk giliran berikutnya keliru. Tinggalkan pesan waktu untuknya.

**Materi tutor yang dapat dibuka:** um + jam • am + hari / bagian hari • im + bulan / musim • Tanpa preposisi.  
**Kosakata sumber:** heute, morgen, gestern, Zeit, Woche. **Latihan asal:** D9.

### Memakai preposisi waktu um, am, im · `a1-u2-o5`

**Frau Lehmann, latihan bersama.** Pilih am untuk hari/bagian hari, um untuk jam, im untuk bulan/musim. heute, morgen, gestern dapat berdiri sendiri.

**Mia** — „Schreib bitte auf, wann wir uns treffen.“  
*Tolong catat kapan kita bertemu.*

**Giliran pemain.** Lengkapi «am Freitag», «am Vormittag», «um neun Uhr», «im Mai», «im Sommer». Susun pesan «Morgen um neun Uhr.»

**Jika maksud tersampaikan.** Pesan masuk ke saku buku tamu, lengkap dengan waktu.

**Jika butuh bantuan.** Jika semua memakai am, kelompokkan kotak hari, jam, bulan. Coba «gestern», «heute» dan «im Winter» pada catatan baru.

**Dialog transisi.**

**Mia** — „Moment mal. Das Foto da kenne ich.“  
*Tunggu. Aku kenal foto itu.*

## Contoh cabang saat maksud belum jelas

**Penjual** — „Siebzig? Schau mal, auf dieser Kiste steht siebzehn.“  
*Tujuh puluh? Coba lihat, di peti ini tertulis tujuh belas.*

Tampilkan label harga ketika bantuan dipilih. Beri kesempatan mendengar harga peti lain.

## Pertemuan mandiri

Kios lain menawarkan barang seharga 21 euro, tersedia Sabtu pukul 08.45. Tanyakan harga dan jadwal, lalu pilih waktu pengambilan yang tepat.

Tutor menyimpan contoh sampai diminta. Catat tujuan yang benar-benar dijawab pada adegan ini. Untuk tujuan yang belum terlihat mandiri, buka variasi baru pada bagian bantuan di atas dan simpan hasil per tujuan.

## Penutup

Di balik kuitansi ada foto keluarga yang terlipat. Mia mengenali rumah di foto, tetapi dua orang memakai nama keluarga yang sama.

## Sambungan ke materi aplikasi

| Tujuan | Pelajaran sumber | Adegan utama |
|---|---|---|
| `a1-u2-o1` | 1 | 1 |
| `a1-u2-o2` | 1 | 1 |
| `a1-u2-o3` | 2 | 2 |
| `a1-u2-o4` | 2 | 2 |
| `a1-u2-o5` | 3 | 3 |

**Bacaan katalog Arena:** *Der Wochenmarkt* (textId 6), *Uhrzeit und Termine* (textId 7)

**Latihan dan checkpoint:** ambil latihan per unit dan nomor pelajaran dari [materi A1](../../src/data/lessons/units_a1.json) dan [latihan terpetakan](../../src/data/lessons/a1_lesson_practice.json), serta butir dari [bank Unit 2](../../src/data/lessons/a1_unit2_bank.json). Jaga identitas dan hasil checkpoint lama terpisah dari penilaian percakapan.
