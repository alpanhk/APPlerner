# Peta produksi kampanye A1–B2 · Lernen

Setiap baris adalah penugasan penulisan dan integrasi. Kolom terakhir menyebut bukti perilaku minimum. Penulis menurunkannya menjadi tujuan, prasyarat, latihan, respons alternatif, kesalahan lazim, remediasi, dan beberapa tugas baru. Topik tata bahasa di seed adalah bahan untuk telaah level; pengajar memutuskan bentuk mana cukup dikenali dan mana perlu diproduksi. Gunakan rubrik komunikasi pada [mandat induk](../Mandat-Induk-Ketuntasan-A1-B2.md).

## A1

| Unit | Tema di aplikasi | Peristiwa cerita | Tugas transfer yang harus dapat diamati |
|---:|---|---|---|
| 1 | Salam & perkenalan diri | Kenalan di ambang rumah | Sapa sesuai waktu dan perkenalkan teman pada tamu baru; nama saja cukup untuk mengenali orang, perkenalan lengkap perlu bukti tersendiri. |
| 2 | Angka, waktu, harga | Titipan kios pasar | Ambil pesanan dengan harga dan waktu yang didengar; ulang pada pasangan angka serta jadwal baru. |
| 3 | Keluarga & hubungan | Bingkai keluarga tertukar | Jelaskan hubungan dua orang pada bagan keluarga fiktif baru sehingga bingkai dikirim ke alamat yang tepat. |
| 4 | Makanan & minuman | Dua meja di Im Café | Pesan sesuai kebutuhan tamu, minta tagihan terpisah; pindah meja dan tanggapi perubahan pesanan. |
| 5 | Belanja & harga | Tas belanja tertukar | Jelaskan ukuran dan warna pada struk lalu minta penukaran pada kasir lain. |
| 6 | Rumah & tempat tinggal | Menata ruang warga | Baca denah, jelaskan lokasi kunci, lalu arahkan seseorang memindahkan kursi ke tempat baru. |
| 7 | Kota & petunjuk arah | Memandu tamu | Dengarkan tujuan, pilih halte, lalu berikan dua arahan pada rute berbeda. |
| 8 | Pekerjaan & kegiatan harian | Giliran meja informasi | Susun tiga pekerjaan, jelaskan jam bertugas dan sepakati pengganti memakai jadwal baru. |
| 9 | Kesehatan & tubuh | Menemani Mia ke praktik | Dengarkan keluhan tokoh fiktif, sebut durasi, minta janji yang memenuhi batas waktu kedua pihak. |
| 10 | Waktu luang & hobi | Menemukan klub | Tolak ajakan saat bentrok, tawarkan waktu baru lalu jelaskan kebiasaan latihan. |
| 11 | Transportasi & perjalanan | Peron berubah | Baca tiket, dengar peron terbaru tanpa bocoran angka dan tanyakan sambungan; ulang dengan audio baru. |
| 12 | Komunikasi & janji | Sekarang kamu yang mengundang | Jawab telepon, catat pesan dan tulis konfirmasi waktu/tempat kepada pendatang baru. |

## A2

| Unit | Tema di aplikasi | Peristiwa cerita | Tugas transfer yang harus dapat diamati |
|---:|---|---|---|
| 101 | Wohnen & Miete | Pemanas apartemen berhenti | Jelaskan kepada pemilik apa yang sudah dicoba, pahami dua slot teknisi, sepakati jam, kirim konfirmasi pada alamat baru. |
| 102 | Arbeit & Beruf | Menukar giliran kerja | Dengar mengapa rekan kemarin harus pulang, ceritakan kewajibanmu, isi penggantian jadwal dan jelaskan pada rekan lain. |
| 103 | Einkaufen & Konsum | Mengembalikan barang | Bandingkan iklan dengan struk, ceritakan kondisi saat membeli dan minta penyelesaian untuk barang lain. |
| 104 | Gesundheit & Arzt | Panggilan dari praktik | Catat yang boleh atau perlu dilakukan berdasarkan pesan praktik fiktif; sampaikan batasan dan minta janji pengganti. |
| 105 | Reisen & Urlaub | Koper yang tertinggal | Ceritakan rute perjalanan lampau dan tentukan tempat mengambil koper dari pesan baru. |
| 106 | Verkehr & Orientierung | Rute pengalihan trem | Pahami papan dan arahan lisan, pandu teman dan penumpang asing dengan sapaan yang sesuai. |
| 107 | Freizeit & Hobbys | Akhir pekan bersama | Bandingkan preferensi dan jadwal tiga orang; ajukan kegiatan sampai ada kesepakatan. |
| 108 | Medien & Kommunikation | Pesan yang salah alamat | Ringkas isi pesan orang lain lalu kirim klarifikasi singkat kepada penerima yang benar. |
| 109 | Feste & Traditionen | Undangan perayaan | Pahami undangan, ceritakan singkat tradisi masa lalu dan sepakati apa yang akan dibawa. |
| 110 | Umwelt & Alltag | Hari pengumpulan barang | Baca pemberitahuan dan dengarkan perubahan; jelaskan cara barang dikumpulkan, lalu beritahu tetangga jadwal barunya. |

## B1

| Unit | Tema di aplikasi | Peristiwa cerita | Tugas transfer yang harus dapat diamati |
|---:|---|---|---|
| 201 | Wohnen & Nachbarschaft | Rapat renovasi ruang warga | Bandingkan usulan, jelaskan ruang yang diperlukan, ajak mitra memilih lokasi dan kirim keputusan. |
| 202 | Gesundheit & Lebensstil | Menyiapkan kegiatan kebugaran | Bandingkan kebiasaan dan saran dalam dua pesan; jelaskan usulan yang realistis dan jawab keberatan. |
| 203 | Arbeit & Karriere | Melamar tugas relawan | Pahami deskripsi posisi, ceritakan pengalaman relevan, jawab pertanyaan dan tulis surel formal tentang satu persyaratan. |
| 204 | Medien & Meinung | Buletin lingkungan | Bedakan fakta dan pendapat dua narasumber, sampaikan kembali dengan atribusi dan tulis tanggapan forum. |
| 205 | Umwelt & Klima | Mengurangi sampah acara | Rencanakan pembagian tugas dan tanggapi saran yang tak sesuai anggaran; tulis hasil kesepakatan. |
| 206 | Reisen & Kultur | Tamu terlewat kereta | Rekonstruksi urutan peristiwa, jelaskan penyebab dan susun rencana baru bersama mitra. |
| 207 | Gesellschaft & Zusammenleben | Siapa mendapat giliran ruangan? | Ajukan keinginan dua kelompok, cari titik temu dan jelaskan komprominya kepada anggota lain. |
| 208 | Bildung & Lernen | Mendirikan klub belajar | Jelaskan tujuan dan pengalaman, presentasikan cara belajar lalu jawab pertanyaan baru. |
| 209 | Geld & Finanzen | Anggaran acara berubah | Baca rincian biaya, jelaskan akibat jika biaya naik dan rundingkan pilihan pengganti. |
| 210 | Technik & Zukunft | Teknologi untuk papan warga | Bandingkan papan fisik dan digital, bawakan presentasi singkat lalu jawab keberatan audiens yang baru. |

## B2

| Unit | Tema di aplikasi | Peristiwa cerita | Tugas transfer yang harus dapat diamati |
|---:|---|---|---|
| 301 | Arbeitswelt im Wandel | Usulan jadwal kerja fleksibel | Bandingkan memo kebijakan dan wawancara pekerja, tulis usulan formal dan tanggapi konsekuensi untuk kelompok lain. |
| 302 | Politik & Gesellschaft | Konsultasi publik jalur trem | Uraikan pendirian dua pihak, timbang manfaat/kerugian, debat dengan mitra dan kirim rekomendasi resmi. |
| 303 | Wissenschaft & Forschung | Temuan penelitian kota | Ringkas hasil dan keterbatasan dua sumber, jelaskan mana kesimpulan yang dapat didukung dan jawab pertanyaan audiens. |
| 304 | Wirtschaft & Unternehmen | Negosiasi dengan sponsor | Bandingkan syarat dua tawaran, klarifikasi klausul, negosiasikan perubahan dan dokumentasikan kompromi. |
| 305 | Klimapolitik & Ressourcen | Prioritas energi ruang warga | Pertahankan pilihan berdasarkan dua bukti, tanggapi kontraargumen dan revisi rekomendasi ketika batas biaya berubah. |
| 306 | Medien & Desinformation | Kabar simpang siur | Bandingkan pernyataan sumber, bedakan atribusi dari kepastian, tulis koreksi forum dan tanggapi pembaca kritis. |
| 307 | Kultur & Identität | Program festival yang inklusif | Pahami nuansa pendapat peserta, presentasikan dua alternatif dan mediasi keberatan dengan bahasa yang tepat. |
| 308 | Medizin & Gesundheit | Akses layanan kesehatan | Bandingkan penjelasan institusi dan pengalaman pengguna fiktif, minta klarifikasi formal dan rangkum masalah akses. |
| 309 | Recht & Verwaltung | Surat balasan dari kantor kota | Uraikan ketentuan administratif fiktif dalam bahasa sehari-hari, tulis permintaan klarifikasi yang menyebut pengecualian. |
| 310 | Zukunft & Ethik | Sidang keputusan akhir | Pimpin pembahasan berlawanan pandangan, pertahankan rekomendasi, revisi ketika ada bukti baru, lalu serahkan ringkasan tertulis. |

Total produksi mencakup 42 unit awal. Jumlah adegan, bahan, suara dan latihan bertambah sesuai celah pada tujuan dan bukti belajar. Pemain yang mengulang suatu tujuan mendapat situasi atau sumber baru dengan kesulitan setara.
