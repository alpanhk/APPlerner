# Lernen · Dari cerita ke persiapan ujian bahasa Jerman

**Acuan pelaksanaan v1.7.** Terapkan cetak biru ujian berikut bersama [aturan ketuntasan, target per level dan protokol bukti hasil peserta](Mandat-Induk-Ketuntasan-A1-B2.md).

**Rancangan produk v1.6 · 21 November 2026.** Sasaran pertama adalah Goethe-Zertifikat untuk peserta dewasa, dari A1 sampai B2. Pemain menyelesaikan sesuatu yang bermakna dalam cerita, kemudian membuktikan kemampuan yang sama dengan bahan baru dan kondisi yang makin mendekati ujian. Profil telc, jika dikembangkan, memiliki cetak biru, aturan dan rubrik sendiri. Tugas kelas menggunakan karya orisinal Lernen.

## Peran pemain tumbuh bersama kemampuan bahasa

| Level dan kaitan ke unit yang sudah ada | Apa yang ingin dicapai pemain | Hören · menyimak | Lesen · membaca | Schreiben · menulis | Sprechen · berbicara |
|---|---|---|---|---|---|
| **A1 · Aku baru tiba.** 12 unit, dari perkenalan sampai komunikasi dan janji. | Menemukan orang yang tepat, sampai ke tempat tujuan, mengirim undangan pertamanya. | Ambil jam atau peron dari pengumuman pendek. | Temukan tujuan pada tiket atau waktu pada undangan. | Isi formulir fiktif dan tulis pesan singkat berisi waktu serta tempat. | Perkenalkan diri, ajukan dan jawab pertanyaan sederhana, minta sesuatu secara sopan. |
| **A2 · Aku mengurus keseharianku.** Unit 101–110. | Ada masalah di tempat tinggal. Pemain mengatur kunjungan teknisi tanpa membatalkan janji kerja. | Dengarkan pesan pemilik rumah dan temukan dua pilihan waktu. | Cocokkan pesan dengan jadwal kerja dan pengumuman gedung. | Beri tahu rekan tentang perubahan jadwal dan kirim permintaan sopan kepada pemilik rumah. | Jelaskan rutinitas pribadi, ajukan usulan, tanggapi penolakan dan sepakati waktu. |
| **B1 · Tetangga mulai mengandalkanku.** Unit 201–210. | Ruang warga akan direnovasi. Pemain membantu memindahkan acara sambil menjaga kepentingan dua kelompok. | Tangkap gagasan utama dan alasan dua pembicara. | Bandingkan surel panitia, pemberitahuan resmi dan pendapat warga. | Tulis surel pribadi atau formal sesuai penerima dan sampaikan pendapat dalam forum. | Rencanakan acara bersama mitra, bawakan presentasi singkat dan jawab satu pertanyaan baru. |
| **B2 · Aku mewakili komunitasku.** Unit 301–310. | Dewan kota mempertimbangkan perubahan layanan trem. Pemain membawa suara warga dan menegosiasikan rekomendasi. | Kenali sikap pembicara, alasan dan keberatan dalam wawancara atau diskusi. | Bandingkan artikel, komentar dan ketentuan layanan. Kenali klaim, pengecualian dan sudut pandang. | Tulis pendapat beralasan untuk forum dan pesan formal dalam konteks profesional. | Presentasikan pilihan, bandingkan kelebihan/kekurangan, jawab sanggahan mitra lalu simpulkan posisi. |

Satu konflik utama menghubungkan beberapa unit. Setiap unit tetap mempunyai tujuan yang dapat diulang sendiri. A2–B2 di tabel adalah usulan kampanye berdasarkan tema yang sudah tersimpan. Untuk produksi, lanjutkan penulisan adegan dan pemetaan tugas per unit, dimulai dari satu unit per level. [Unit A1](../src/data/lessons/units_a1.json) · [Unit A2](../src/data/lessons/units_a2.json) · [Unit B1](../src/data/lessons/units_b1.json) · [Unit B2](../src/data/lessons/units_b2.json)

## Pola satu misi yang dapat digunakan penulis

1. **Situasi.** Awali dengan kebutuhan NPC dan konsekuensi yang tampak. Tampilkan satu tujuan praktis, misalnya “Bantu Mia menemukan kereta sebelum berangkat.”
2. **Contoh dan pemahaman.** Tutor memberi satu contoh bahasa singkat. Cek apakah pemain memahami maksudnya dengan satu tindakan pada dunia cerita. Di A1 gunakan dukungan bahasa Indonesia sesuai kebutuhan. Di B1–B2 tutor meminta pemain membandingkan alasan atau mengklarifikasi maksud; bantuan tetap dapat dipanggil.
3. **Penggunaan.** Tahan cerita sampai giliran pemain. Terima jawaban yang menyampaikan maksud dengan register memadai. Saat ada salah paham, NPC meminta klarifikasi yang masuk akal. Tutor menawarkan petunjuk spesifik; ketika soal menilai kemampuan mendengar, catat penggunaan transkrip.
4. **Akibat dan umpan balik.** Tunjukkan akibat terlebih dahulu, misalnya Mia bergerak ke peron yang dipilih. Sebutkan satu hal yang dipahami dan satu perbaikan yang bisa langsung dicoba. Sediakan jalur pulih agar kesalahan tidak menghapus progres cerita.
5. **Transfer.** Di akhir rangkaian, ganti stimulus, tokoh atau tujuan. Gunakan materi yang belum diputar selama latihan. Minta respons individual yang sesuai keterampilan. Pada akhir sesi berikutnya, tawarkan satu tugas baru pada kemampuan yang sebelumnya lemah.
6. **Jurnal.** Tampilkan hasil konkret seperti “Kamu memahami perubahan peron melalui audio; kamu masih perlu mengulang jam kedatangan.” Sediakan *Coba jadwal lain*. Pemain boleh melanjutkan cerita sambil menyimpan latihan yang masih perlu diulang.

### Contoh siap dibuat · Stasiun A1

| Giliran | Yang terjadi | Apa yang disimpan |
|---|---|---|
| Baca | Di Bab 11 Mia menyerahkan tiket. Pemain mengambil jam keberangkatan dari tiket, lalu membedakannya dari jam tiba. | Tujuan `a1-u11-o2`, jawaban dan sumber informasi visual. |
| Simak | Pasang latar peron dan keluarkan pengumuman lokal “Der Zug fährt heute von Gleis vier ab.” Tiket menampilkan informasi lama. Selama percobaan menyimak, angka baru di papan belum terlihat. Setelah pemain memilih, tampilkan papan terbaru. | `a1-u11-o4`, pilihan, jumlah putar ulang, apakah transkrip dibuka. Jika klip gagal, sediakan teks dan tandai bukti sebagai membaca. |
| Berbicara | Petugas menunggu. Pemain menanyakan peron. Terima variasi sopan seperti “Entschuldigung, von welchem Gleis fährt der Zug ab?” Lanjutkan dengan satu pertanyaan balik. | Rekaman lokal opsional dan jawaban balik. Jika pemain memilih mengetik, catat latihan tertulis. Putar contoh suara avatar sebagai model dengar. |
| Menulis | Hubungkan ke Bab 12. Pemain memberi kabar kepada Mia tentang waktu dan tempat bertemu sesuai tiket terakhir. Terima beberapa susunan kalimat selama informasi benar. | `a1-u12-o5`, teks asli, kelengkapan pesan dan perbaikan kedua. |
| Transfer | Pada hari berbeda, pakai rute dan rekaman lain. Pastikan angka pada audio, keadaan papan, jawaban yang diterima serta konsekuensi memakai satu versi skenario. | Hasil baru per keterampilan. Jika konten alternatif belum ada, status tugas *menunggu stimulus*. |

Gunakan empat avatar, Frau Lehmann dan Mia untuk kontinuitas; latar peron, loket, tiket, papan dan klip terpetakan sudah tersedia sebagai sumber produksi. Periksa kecocokan ID dan hak distribusi sebelum pengemasan. Di tingkat lanjut, lingkungan yang sama dapat dipakai untuk merencanakan perjalanan A2, menyelesaikan konflik agenda B1 atau berunding soal transportasi publik B2. Dialog, kecepatan dan tugas harus disusun untuk levelnya. [Sumber aset dan naskah A1](naskah-visual-novel-a1/README.md)

## Tiga pilihan pada aplikasi

| Pilihan pemain | Kondisi | Hasil |
|---|---|---|
| **Main cerita** | Tutor, arti, transkrip, contoh, jeda dan putar ulang dapat digunakan kapan saja. | Perkembangan cerita dan daftar ungkapan yang sudah digunakan. |
| **Latih keterampilan** | Masuk dari jurnal atau pustaka. Mulai dengan situasi baru; petunjuk bertahap tersedia bila diperlukan. Ada latihan dengar, baca, tulis dan bicara secara terpisah. | Bukti per tujuan, konteks, jenis bantuan, bentuk respons dan kebutuhan pengulangan. |
| **Simulasi ujian** | Pemain memilih level dan profil penyelenggara. Jelaskan aturan sebelum mulai. Gunakan set terpisah dari bank latihan, waktu bagian dan kebijakan pemutaran sesuai model resmi yang dipilih. Simpan jawaban saat gangguan. Beri pembahasan setelah bagian selesai. | Ringkasan per keterampilan, waktu dan hasil koreksi. Respons tulis/lisan yang belum diperiksa tampil sebagai *menunggu penilaian*. |

**Cetak biru awal.** Acuan Goethe dewasa di bawah dicatat pada 21 November 2026. Durasi dalam menit mengikuti urutan pada header. Waktu persiapan lisan, instruksi, jumlah pemutaran dan skema penilaian dicatat terpisah per versi model sebelum simulasi lengkap diterbitkan. A1/A2 terdiri dari bagian ujian. B1/B2 memiliki empat modul yang dapat diambil tersendiri atau bersama. UI dapat menyediakan latihan per bagian di semua tingkat.

| Profil ujian | Hören | Lesen | Schreiben | Sprechen | Bentuk lisan yang perlu dilatih |
|---|---:|---:|---:|---:|---|
| [Goethe A1 · Start Deutsch 1](https://www.goethe.de/ins/de/de/prf/gzsd1.cfm) | 20 | 25 | 20 | 15 | Perkenalan, bertanya, menjawab dan meminta dalam kelompok. |
| [Goethe A2](https://www.goethe.de/ins/de/de/prf/gzsd2.cfm) | 30 | 30 | 30 | 15 | Bertanya, bercerita tentang diri sendiri, membuat rencana dengan mitra. |
| [Goethe B1](https://www.goethe.de/ins/de/de/prf/gzb1.cfm) | 40 | 65 | 60 | 15 | Perencanaan bersama, presentasi dan tanya jawab. |
| [Goethe B2](https://www.goethe.de/ins/de/de/prf/gzb2.cfm) | 40 | 65 | 75 | 15 | Presentasi, tanggapan dan pertukaran argumen. |

**Kesenjangan yang langsung dapat ditindaklanjuti:** set A1 yang ada menyediakan 8/10/10/5 menit dengan rubrik mandiri pada dua bagian produktif. Sajikan sebagai *Latihan singkat A1 · 33 menit*. Buat jalur terpisah untuk simulasi lengkap. Sebelum memberi nilai simulasi yang dibandingkan dengan target Goethe, pengajar memverifikasi format, rubrik, konversi skor dan ketentuan lulus untuk level serta versi yang tepat. Ambang checkpoint unit lama tetap merupakan ukuran belajar lokal. [Set singkat saat ini](../src/data/practice/a1_mock_exam.json)

## Bukti, penilaian dan tindak lanjut

- **Hören/Lesen.** Simpan jenis pemahaman (gagasan utama, detail, sikap), stimulus yang dilihat/didengar, upaya pertama dan bantuan. Bila peserta mengidentifikasi peron tetapi salah jam, beri latihan diskriminasi jam berikutnya. Hindari panel judul, ilustrasi atau ringkasan yang membocorkan detail sasaran.
- **Schreiben.** Simpan tulisan utuh. Nilai apakah tugas terpenuhi, informasi akurat, susunan dapat diikuti, register sesuai, dan kendali bahasa memadai untuk level. Bagi B2 tambahkan pengembangan alasan dan keterkaitan argumen. Sorot satu bagian spesifik, izinkan revisi. Jurnal mempertahankan versi awal dan versi revisi.
- **Sprechen.** Tawarkan rekam, dengarkan sendiri, rekam ulang dalam mode belajar, dan giliran merespons mitra. Persetujuan mikrofon dan penghapusan rekaman berada di tangan pengguna. Amati penyelesaian tugas, keterpahaman, kelancaran, pengembangan ide dan interaksi yang relevan dengan level. Bila mikrofon tidak tersedia, lanjutkan cerita melalui teks dan sediakan opsi latihan lisan bersama mitra.
- **Kesiapan.** Jurnal menunjukkan *belum ada sampel*, *dengan bantuan*, *mandiri pada tugas baru*, atau *hasil simulasi ditelaah*. Cantumkan waktu dan jumlah tugas yang menjadi dasar. Sebelum menyarankan simulasi penuh, sasaran internal rancangan adalah dua tugas baru mandiri per keterampilan pada kesempatan berbeda, termasuk bukti produksi tulis serta lisan. Uji kelayakan sasaran ini saat pilot. Jika satu modul lemah, lanjutkan modul lain dan anjurkan remediasi yang spesifik. Sertifikat serta keputusan lulus ujian resmi tetap berada pada lembaga ujian.
- **Kontrak konten dan progres.** Setiap tugas menyimpan ID tujuan yang stabil, level CEFR, keterampilan, jenis tugas, bab/adegan, stimulus dan variannya, rubrik versi tertentu, peran mitra, kondisi bantuan dan penilaian. Simpan data simulasi dengan identitas profil ujian dan versi model. Jangan mengubah nilai latihan lama menjadi bukti simulasi. Data A1 yang memiliki ID tujuan dapat dipetakan langsung; pada A2–B2 petakan dan telaah tujuan turunan sebelum menampilkan cakupan.

## Tahap pengerjaan dan penerimaan

1. **A1 dahulu.** Gunakan 12 naskah, 36 pelajaran dan 60 tujuan sumber. Buat matriks tujuan × keterampilan × tugas; satu tujuan tidak wajib muncul di keempat keterampilan. Tandai sel kosong yang penting untuk ujian. Buat satu alur lengkap Bab 11–12 beserta stimulus transfer. Penguji membuktikan empat hasil yang terpisah dengan skenario benar, bantuan, dan kesalahan yang dapat dipulihkan. Periksa juga bahwa mengetik tidak menaikkan capaian lisan dan suara yang gagal tidak memberi capaian menyimak.
2. **Satu misi per tingkat berikut.** A2 unit 101 memakai janji perbaikan rumah, B1 unit 201 memakai rapat tetangga, B2 unit 302 memakai konsultasi publik. Siapkan satu set transfer dan rubrik tulis/lisan untuk masing-masing. Pengajar memeriksa kesulitan, kewajaran bahasa, dan contoh jawaban alternatif; pelajar mencoba tanpa arahan operator. Periksa apakah peserta memahami isi saat gambar, nama, urutan dan lawan bicara diganti.
3. **Perluas ke 10 unit per tingkat A2–B2.** Tiap kemampuan ujian memiliki latihan dengan bantuan, tugas baru tanpa bantuan dan sampel terpisah untuk simulasi. Koreksi dua contoh tulisan dan dua rekaman per level bersama penelaah agar penggunaan rubrik konsisten. Laporkan bagian yang belum dicoba manusia. Kepemilikan level dan progres cerita terpisah supaya pengguna berpengalaman dapat langsung mencoba latihan penempatan atau satu modul sasaran.
4. **Siapkan ekspansi.** CEFR mempunyai enam level resmi, A1, A2, B1, B2, C1 dan C2. Siapkan format konten untuk kampanye C1/C2. Setelah C2, gunakan label produk *C3 — Jalur Pakar Lernen* untuk spesialisasi yang disetujui pengguna, misalnya moderasi debat profesional, penyuntingan teks kompleks dan sintesis lintas sumber. Rekam sebagai jalur internal tanpa nilai `cefrLevel=C3`; tampilkan portofolio tugas dan rubrik spesialisasi. Publikasi tiap kampanye menunggu materi dan bukti uji untuk tingkat itu. [Skala resmi Council of Europe](https://www.coe.int/en/web/common-european-framework-reference-languages/level-descriptions)
